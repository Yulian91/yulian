<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <title>Gestión Tecnología Biomédica</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="icon" type="image/png" href="/gestion_tecnologias/Util/img/tools.png" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&amp;display=fallback">
  <link rel="stylesheet" type="text/css" href="/gestion_tecnologias/Util/css/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="/gestion_tecnologias/Util/css/css/util.css">
  <link rel="stylesheet" type="text/css" href="/gestion_tecnologias/Util/css/css/login.css">
  <link rel="stylesheet" type="text/css" href="/gestion_tecnologias/Util/css/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="/gestion_tecnologias/Util/css/adminlte.min.css">
  <link rel="stylesheet" type="text/css" href="/gestion_tecnologias/Util/css/sweetalert2.min.css">
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/toastr.min.css">
  
</head>

<body>

  <div class="limiter">
    <div class="container-login100">
      <div class="wrap-login100 p-l-85 p-r-85 p-t-55 p-b-55">
        <form id="form-login" class="login100-form validate-form flex-sb flex-w">
          <span class="login100-form-title p-b-32 text-center">
            Gestión Tecnología Biomédica
          </span>

          <span class="txt1 p-b-11">
            Identificación
          </span>
          <div class="wrap-input100 validate-input m-b-36" data-validate="Campo obligatorio">
            <input class="input100" type="text" name="username" id="ident">
            <span class="focus-input100"></span>
          </div>

          <span class="txt1 p-b-11">
            Contraseña
          </span>
          <div class="wrap-input100 validate-input m-b-12" data-validate="Campo obligatorio">
            <span class="btn-show-pass">
              <i class="fa fa-eye"></i>
            </span>
            <input class="input100" type="password" name="pass" id="pass">
            <span class="focus-input100"></span>
          </div>

          <div class="flex-sb-m w-full p-b-48">
            <div class="contact100-form-checkbox">
              <input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
              <label class="label-checkbox100" for="ckb1">
                Recordarme
              </label>
            </div>

            <div>
              <a href="#" class="txt3">
                ¿Olvide la contraseña?
              </a>
            </div>
          </div>

          <div class="container-login100-form-btn">
            <button type="submit" class="login100-form-btn">
              Iniciar Sesión
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

</body>

<!-- jQuery -->
<script src="/gestion_tecnologias/Util/js/jquery.min.js"></script>
<!-- sweetalert2 -->
<script src="/gestion_tecnologias/Util/js/sweetalert2.min.js"></script>
<!-- Bootstrap 4.6 -->
<script src="/gestion_tecnologias/Util/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/gestion_tecnologias/Util/js/adminlte.min.js"></script>
<script src="/gestion_tecnologias/Util/js/main.js"></script>
<script src="/gestion_tecnologias/index.js"></script>
<!-- Toastr -->
<script src="/gestion_tecnologias/Util/js/toastr.min.js"></script>

</html>