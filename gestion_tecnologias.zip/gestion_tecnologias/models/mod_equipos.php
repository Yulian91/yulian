<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/config/conexion_db.php';

// CLASE PARA REALIZAR LA CONEXION PDO
class Equipos
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  function obtener_equipos()
  {
      $sql = "SELECT 
      eq.id AS id,
      ti.nombre AS tipo_equipo,
      eq.codigo,
      eq.marca,
      eq.modelo,
      eq.no_serie,
      ac.nombre AS accesorio,
      eq.fijo_movil,
      eq.reg_invima,
      eq.frecuencia_matto,
      ri.nombre AS riesgo_clase,
      ub.nombre AS ubicacion,
      ar.nombre AS area,
      eq.estado,
      eq.fecha_reg,
      eq.fecha_edi
      FROM equipo eq
      JOIN tipo_equipo ti ON eq.tipo_equipo=ti.id
      JOIN accesorio ac ON eq.accesorio=ac.id
      JOIN riesgo ri ON eq.riesgo=ri.id
      JOIN ubicacion ub ON eq.ubicacion=ub.id
      JOIN area ar ON eq.area=ar.id
      WHERE eq.estado = 'A' ORDER BY eq.marca";
      /*$var = array(
        ':ident' => $ident
      );*/
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
  }

  /*function obtener_stock($id)
  {
    $sql = "SELECT SUM(stock) AS total_productos FROM lote WHERE id=:id AND estado = 'ACTIVO'";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }*/

//------------------------------------------------------------------------------------------------------- 

  function Crear_Usuario($nombre, $apellido, $email, $identificacion, $contacto, $direccion, $contrasena, $tipo)
  {
    $sql = "SELECT idusuario FROM usuario WHERE identificacion=:identificacion";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':identificacion' => $identificacion));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO usuario(nombre,apellidos,email,identificacion,telefono,direccion,contrasena,tipo_usu) VALUES (:nombre,:apellido,:email,:identificacion,:contacto,:direccion,:contrasena,:tipo);";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':nombre' => $nombre, ':apellido' => $apellido, ':email' => $email, ':identificacion' => $identificacion, ':contacto' => $contacto, ':direccion' => $direccion, ':contrasena' => $contrasena, ':tipo' => $tipo));
      echo 'add';
    }
  }

  function Login($ident)
  {
    $sql = "SELECT u.id AS id, u.nombre AS nombre, u.apellido AS apellido, u.email AS email, 
            u.identificacion AS ident, u.contrasena AS contrasena, u.id_tipo AS id_tipo, 
            t.nombre_tipo AS tipo_usuario, u.estado AS estado, u.avatar AS avatar
            FROM usuario u JOIN tipo_usuario t ON u.id_tipo = t.id WHERE u.identificacion = :ident";
    $var = array(
      ':ident' => $ident
    );
    $query = $this->acceso->prepare($sql);
    $query->execute($var);
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  function obtener_datos($id_usuario)
  {
    $sql = "SELECT * FROM usuario INNER JOIN tipo_usuario ON tipo_usu=id_tipo WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario));
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  // FUNCION PARA ACTUALIZAR LOS DATOS DEL USUARIO EN LA BASE DE DATOS
  function editar_datos($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion)
  {
    $sql = "UPDATE usuario SET nombre=:nombre, apellidos=:apellidos, identificacion=:identificacion, email=:email, telefono=:contacto, direccion=:direccion WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario, ':nombre' => $nombre, ':apellidos' => $apellidos, ':identificacion' => $identificacion, ':email' => $email, ':contacto' => $contacto, ':direccion' => $direccion));
    echo 'update_datos';
  }
  // FIN

  function editar_usuario($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion, $contrasena, $tipo)
  {
    $sql = "UPDATE usuario SET nombre=:nombre, apellidos=:apellidos, identificacion=:identificacion, email=:email, telefono=:contacto, direccion=:direccion, contrasena=:contrasena, tipo_usu=:tipo  WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario, ':nombre' => $nombre, ':apellidos' => $apellidos, ':identificacion' => $identificacion, ':email' => $email, ':contacto' => $contacto, ':direccion' => $direccion, ':contrasena' => $contrasena, ':tipo' => $tipo));
    echo 'update_usu';
  }

  // FUNCION PARA CAMBIAR LA CONTRASEÑA EN LA BASE DE DATOS
  function cambio_clave($id_usuario, $clave_anterior, $nueva_clave)
  {
    $sql = "SELECT * FROM usuario WHERE id_usuario=:id AND password=:clave_anterior";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_usuario, ':clave_anterior' => $clave_anterior));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      $sql = "UPDATE usuario SET password=:nueva_clave WHERE id_usuario=:id";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':id' => $id_usuario, ':nueva_clave' => $nueva_clave));
      echo 'update';
    } else {
      echo 'noupdate';
    }
  }
  // FIN

  // FUNCION PARA BUSCAR LOS USUARIOS REGISTRADOS EN LA BASE DE DATOS
  function buscador_usuarios()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_usuario, nombre, apellidos, email, identificacion, telefono, direccion, contrasena, tipo_usu, tipo_usuario.nombre_tipo, estatus_usu
      FROM usuario 
      INNER JOIN tipo_usuario ON tipo_usu=id_tipo AND id_usuario LIKE :consulta LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_usuario, nombre, apellidos, email, identificacion, telefono, direccion, contrasena, tipo_usu, tipo_usuario.nombre_tipo, estatus_usu
      FROM usuario 
      INNER JOIN tipo_usuario ON tipo_usu=id_tipo WHERE nombre NOT LIKE '' ORDER BY id_usuario LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  // FIN

  function inhabilitar($id)
  {
    $sql = "UPDATE usuario SET estatus_usu = 'INACTIVO' WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'inactivado';
    } else {
      echo 'noinactivado';
    }
  }

  function habilitar($id)
  {
    $sql = "UPDATE usuario SET estatus_usu = 'ACTIVO' WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'activado';
    } else {
      echo 'noactivado';
    }
  }

  function eliminar($id)
  {
    $sql = "DELETE FROM usuario WHERE id_usuario=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }

  function select_usuario()
  {
    $sql = "SELECT * FROM usuario INNER JOIN tipo_usuario ON tipo_usu=id_tipo AND id_tipo=4";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  function select_tecnico_usu()
  {
    $sql = "SELECT * FROM usuario INNER JOIN tipo_usuario ON tipo_usu=id_tipo AND id_tipo=1 ";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  function total_usuarios()
  {
    $sql = "SELECT COUNT(*) AS total_registro FROM usuario";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  function verificar_datos($identificacion, $email)
  {
    $sql = "SELECT * FROM usuario WHERE email=:email AND identificacion=:identificacion";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':email' => $email, ':identificacion' => $identificacion));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      if ($query->rowCount() == 1) {
        echo 'encontrado';
      } else {
        echo 'no_encontrado';
      }
    } else {
      echo 'no_encontrado';
    }
  }

  function remplazar($identificacion, $email, $codigo)
  {
    $sql = "UPDATE usuario SET password=:codigo WHERE email=:email AND identificacion=:identificacion";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':codigo' => $codigo, ':email' => $email, ':identificacion' => $identificacion));
    echo 'remplazado';
  }
}

// FIN DE LA CLASE
