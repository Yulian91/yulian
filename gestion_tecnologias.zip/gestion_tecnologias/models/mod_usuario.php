<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/gestion_tecnologias/config/conexion_db.php';
class Usuario
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  function login($ident)
  {
    $sql = "SELECT usuario.id, usuario.nombre, usuario.apellido, usuario.identificacion, usuario.password,
    usuario.email, usuario.tipo_usuario AS id_tipo, tipo_usuario.nombre AS tipo_usuario
    FROM usuario 
    JOIN tipo_usuario ON usuario.tipo_usuario = tipo_usuario.id
    WHERE usuario.identificacion = :ident";
    // Variables del array.
    $variables = array(
      ':ident' => $ident
    );
    $query = $this->acceso->prepare($sql);
    $query->execute($variables);
    $this->objetos = $query->fetchAll();
    return $this->objetos;
  }

  // Función para obtener los datos de los usuarios de la base de datos.
  function obtener_usuarios()
  {
    $sql = "SELECT usuario.id, usuario.nombre, usuario.apellido, usuario.identificacion, usuario.password,
    usuario.email, usuario.tipo_usuario AS id_tipo, tipo_usuario.nombre AS tipo_usuario, usuario.estado, 
    usuario.date_add AS fecha_creacion, usuario.date_update AS fecha_edicion
    FROM usuario 
    JOIN tipo_usuario ON usuario.tipo_usuario = tipo_usuario.id
    WHERE usuario.estado = 'A' ORDER BY  tipo_usuario.nombre";
    // Variables del array.
    /*$var = array(
      ':ident' => $ident
    );*/
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  function obtener_datos_usuario($id_usuario)
  {
    $sql = "SELECT usuario.id, usuario.nombre, usuario.apellido, usuario.identificacion, usuario.password,
    usuario.email, usuario.tipo_usuario AS id_tipo, tipo_usuario.nombre AS tipo_usuario, usuario.estado
    FROM usuario 
    JOIN tipo_usuario ON usuario.tipo_usuario = tipo_usuario.id
    WHERE usuario.id = :id_usuario";
    // Variables del array.
    $variables = array(
      ':id_usuario' => $id_usuario
    );
    $query = $this->acceso->prepare($sql);
    $query->execute($variables);
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }

  function crear_usuario($nombre, $apellido, $identificacion, $email, $contrasena, $tipo_usuario)
  {

    $sql = "SELECT id FROM usuario WHERE identificacion=:identificacion";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':identificacion' => $identificacion));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT 
      INTO usuario(nombre,apellido,email,identificacion,password,tipo_usuario) 
      VALUES (:nombre,:apellido,:email,:identificacion,:contrasena,:tipo_usuario)";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':nombre' => $nombre, ':apellido' => $apellido, ':email' => $email,
      ':identificacion' => $identificacion, ':contrasena' => $contrasena, ':tipo_usuario' => $tipo_usuario));
      echo 'add';
    }
    
  }
}
