<!DOCTYPE html>
<html lang="es" class="" style="height: auto;">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&amp;display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/css/all.min.css">
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/css/fontawesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/adminlte.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/datatables.min.css">
  <!-- sweetalert2 -->
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/sweetalert2.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/select2.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="/gestion_tecnologias/Util/css/toastr.min.css">

</head>

<body class="sidebar-mini control-sidebar-slide-open layout-navbar-fixed layout-fixed layout-footer-fixed dark-mode" style="height: auto;">

  <div class="wrapper">

    <nav class="main-header navbar navbar-expand navbar-light bg-lightblue">

      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">
          <a class="nav-link" data-widget="navbar-search" href="#" role="button">
            <i class="fas fa-search"></i>
          </a>
          <div class="navbar-search-block">
            <form class="form-inline">
              <div class="input-group input-group-sm">
                <input class="form-control form-control-navbar" type="search" placeholder="Buscar" aria-label="Search">
                <div class="input-group-append">
                  <button class="btn btn-navbar" type="submit">
                    <i class="fas fa-search"></i>
                  </button>
                  <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="far fa-bell"></i>
            <span class="badge badge-warning navbar-badge">15</span>
          </a>
          <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <span class="dropdown-item dropdown-header">15 Notifications</span>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
              <i class="fas fa-envelope mr-2"></i> 4 new messages
              <span class="float-right text-muted text-sm">3 mins</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
              <i class="fas fa-users mr-2"></i> 8 friend requests
              <span class="float-right text-muted text-sm">12 hours</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
              <i class="fas fa-file mr-2"></i> 3 new reports
              <span class="float-right text-muted text-sm">2 days</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-widget="fullscreen" href="#" role="button">
            <i class="fas fa-expand-arrows-alt"></i>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
            <img src="/gestion_tecnologias/Util/img/avatar.png" width="30" height="30" class="img-fluid img-circle">
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <div class="row">
              <div class="col-md-12">
                <img src="/gestion_tecnologias/Util/img/avatar.png" width="100" height="100" class="img-fluid img-circle">
              </div>
              <div class="row">
                <div class="col-md-12">
                  <span><?php echo $_SESSION['nombre'] ?></span>
                  <span><?php echo $_SESSION['apellido'] ?></span>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <li><a class="dropdown-item" href="/gestion_tecnologias/views/admin/perfil_usuario.php"><i class="fas fa-user-cog"></i>Mi perfil</a></li>
                </div>
                <div class="col-md-6">
                  <li><a class="dropdown-item" href="/gestion_tecnologias/controller/cont_login_salir.php"><i class="fas fa-sign-out-alt"></i>Salir</a></li>
                </div>
              </div>
            </div>
          </ul>
        </li>
      </ul>
    </nav>

    <aside class="main-sidebar sidebar-dark-primary elevation-3">

      <a href="/gestion_tecnologias/" class="brand-link bg-lightblue">
        <img src="/gestion_tecnologias/Util/img/admin_tools.png" alt="Logo" class="brand-image img-circle elevation-4" style="opacity: .8">
        <span class="brand-text font-weight-light">Gestión Tecnologías</span>
      </a>

      <div class="sidebar" style="overflow-y: auto;">

        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="info">
            <a href="#" class="d-block">MENU PRINCIPAL</a>
          </div>
        </div>

        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-header"></li>
            <li class="nav-item">
              <a href="/gestion_tecnologias/views/admin/dashboard.php" class="nav-link active">
                <i class="nav-icon fas fa-house"></i>
                <p>
                  Inicio
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/gestion_tecnologias/views/admin/usuarios.php" class="nav-link">
                <i class="nav-icon fas fa-users"></i>
                <p>
                  Usuarios
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/gestion_tecnologias/views/admin/equipos.php" class="nav-link">
                <i class="nav-icon fas fa-stethoscope"></i>
                <p>
                  Equipos Tecnologicos
                </p>
              </a>
            </li>
        </nav>
      </div>
    </aside>