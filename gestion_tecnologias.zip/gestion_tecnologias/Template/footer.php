<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright © 2022-2023 <a href="#">Pagina Web</a>.</strong> Todos los derechos reservados.
</footer>

</div>

<!-- jQuery -->
<script src="/gestion_tecnologias/Util/js/jquery.min.js"></script>
<!-- Bootstrap 4.6 -->
<script src="/gestion_tecnologias/Util/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/gestion_tecnologias/Util/js/adminlte.min.js"></script>
<!-- DataTables -->
<script src="/gestion_tecnologias/Util/js/datatables.min.js"></script>
<!-- sweetalert2 -->
<script src="/gestion_tecnologias/Util/js/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="/gestion_tecnologias/Util/js/toastr.min.js"></script>

</body>

</html>