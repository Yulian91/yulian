<?php
// Conexión al modelo del usuario.
include_once $_SERVER['DOCUMENT_ROOT'] . '/gestion_tecnologias/models/mod_usuario.php';
// Conexión a las variables globales de Encriptación.
include_once $_SERVER['DOCUMENT_ROOT'] . '/gestion_tecnologias/config/config.php';
// Variable instanciada con el modelo usuario
$usuario = new Usuario();
// Analisar las sesiónes.
session_start();
// Zona horaria
date_default_timezone_set('America/Lima');

/* Recibe las dos variables que se envia desde la funcion login_sesion */
if ($_POST['funcion'] == 'login') {
  $ident = $_POST['ident'];
  $pass = $_POST['pass'];
  $usuario->login($ident);
  $msg = '';
  // Condicional para encontrar la identificación del usuario. 
  if (!empty($usuario->objetos)) {
    // Variable para obtener la contraseña de la base de datos.

    $contrasena = $usuario->objetos[0]->password;
    // Condicional para comparar la contraseña ingresada por el usuario y la registrada en la base de datos.
    if ($pass == $contrasena) {
      // Variables global.
      $_SESSION['id'] = $usuario->objetos[0]->id;
      $_SESSION['nombre'] = $usuario->objetos[0]->nombre;
      $_SESSION['apellido'] = $usuario->objetos[0]->apellido;
      $_SESSION['identificacion'] = $usuario->objetos[0]->identificacion;
      $_SESSION['email'] = $usuario->objetos[0]->email;
      $_SESSION['id_tipo'] = $usuario->objetos[0]->id_tipo;
      $_SESSION['tipo_usuario'] = $usuario->objetos[0]->tipo_usuario;
      // Mensaje para cuando el usuario ingresa la contraseña correcta.
      $msg = 'success';
    } else {
      // Mensaje para cuando el usuario ingresa la contraseña incorrecta.
      $msg = 'error';
    }
  } else {
    // Mensaje para cuando el usuario ingresa una identificación que no existe.
    $msg = 'error';
  }
  // Envia un json, con el valor del dato.
  $json = array(
    'msg' => $msg
  );
  // código para codificar nuestro json y convertirlo en string.
  $jsonstring = json_encode($json);
  echo $jsonstring;
} else
if ($_POST['funcion'] == 'verificar_sesion') {
  // Condicional para comparar la sesiónes.
  if (!empty($_SESSION['id'])) {
    // Cuando la sesión esta abierta.
    $json = array(
      'id' => $_SESSION['id'],
      'nombre' => $_SESSION['nombre'],
      'apellido' => $_SESSION['apellido'],
      'email' => $_SESSION['email'],
      'identificacion' => $_SESSION['identificacion'],
      'id_tipo' => $_SESSION['id_tipo'],
      'tipo_usuario' => $_SESSION['tipo_usuario']
    );
  } else {
    $json = array();
  }
  // código para codificar nuestro json y convertirlo en string.
  $jsonstring = json_encode($json);
  echo $jsonstring;
} else
  // Ejecuta una función
  if ($_POST['funcion'] == 'obtener_usuarios') {
    $usuario->obtener_usuarios();
    $json = array();
    foreach ($usuario->objetos as $objeto) {
      $json[] = array(
        'id' => openssl_encrypt($objeto->id, CODE, KEY),
        'nombre' => $objeto->nombre,
        'apellido' => $objeto->apellido,
        'identificacion' => $objeto->identificacion,
        'password' => $objeto->password,
        'email' => $objeto->email,
        'id_tipo' => $objeto->id_tipo,
        'tipo_usuario' => $objeto->tipo_usuario,
        'estado' => $objeto->estado,
        'fecha_creacion' => $objeto->fecha_creacion,
        'fecha_edicion' => $objeto->fecha_edicion
      );
    }
    // código para codificar nuestro json y convertirlo en string.
    $jsonstring = json_encode($json);
    // Envia un jsonstring.
    echo $jsonstring;
  } else 
if ($_POST['funcion'] == 'obtener_datos_usuario') {
    // Ejecuta una función patra obtener los datos del usuario desde la base de datos.
    $json = array();
    $id_usuario = $_SESSION['id'];
    $usuario->obtener_datos_usuario($id_usuario);
    if (!empty($usuario->objetos)) {
      $json = array(
        'id' => openssl_encrypt($usuario->objetos[0]->id, CODE, KEY),
        'nombre' => $usuario->objetos[0]->nombre,
        'apellido' => $usuario->objetos[0]->apellido,
        'identificacion' => $usuario->objetos[0]->identificacion,
        'password' => $usuario->objetos[0]->password,
        'email' => $usuario->objetos[0]->email,
        'id_tipo' => $usuario->objetos[0]->id_tipo,
        'tipo_usuario' => $usuario->objetos[0]->tipo_usuario,
        'estado' => $usuario->objetos[0]->estado
      );
      // código para codificar nuestro json y convertirlo en string.
      $jsonstring = json_encode($json);
      // Envia un jsonstring.
      echo $jsonstring;
    } else {
      echo 'error';
    }
  } else 
if ($_POST['funcion'] == 'crear_usuario') {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $identificacion = $_POST['identificacion'];
    $contrasena = $_POST['contrasena'];
    $tipo_usuario = $_POST['tipo_usuario'];
    $usuario->crear_usuario($nombre, $apellido, $email, $identificacion, $contrasena, $tipo_usuario);
  }
