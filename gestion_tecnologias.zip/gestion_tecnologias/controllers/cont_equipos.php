<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/models/mod_equipos.php';
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/config/config.php';
$equipos = new  Equipos();

// Funcion para obtener y mostrar los productos 
if ($_POST['funcion'] == 'obtener_equipos') {
  $equipos->obtener_equipos();
  $json = array();
  foreach ($equipos->objetos as $objeto) {
    //$equipos->obtener_stock($objeto->id);
    //$stock = $equipos->objetos[0]->total_equipos;
    $json[] = array(
      'id' => openssl_encrypt($objeto->id,CODE,KEY),
      'tipo_equipo' => $objeto->tipo_equipo,
      'codigo' => $objeto->codigo,
      'marca' => $objeto->marca,
      'modelo' => $objeto->modelo,
      'no_serie' => $objeto->no_serie,
      'accesorio' => $objeto->accesorio,
      'fijo_movil' => $objeto->fijo_movil,
      'reg_invima' => $objeto->reg_invima,
      'frecuencia_matto' => $objeto->frecuencia_matto,
      'riesgo_clase' => $objeto->riesgo_clase,
      //'stock'=>$stock,
      'ubicacion' => $objeto->ubicacion,
      'area' => $objeto->area,
      'estado' => $objeto->estado,
      'fecha_reg' => $objeto->fecha_reg,
      'fecha_edi' => $objeto->fecha_edi
    );
  }

  $jsonstring = json_encode($json);
  echo $jsonstring;
}
// fin Funcion
else
if ($_POST['funcion'] == 'verificar_session') {
  if (!empty($_SESSION['id'])) {
    $json = array(
      'id'=>$_SESSION['id'],
      'nombre'=>$_SESSION['nombre'],
      'apellido'=>$_SESSION['apellido'],
      'email'=>$_SESSION['email'],
      'ident'=>$_SESSION['ident'],
      'estado'=>$_SESSION['estado'],
      'avatar'=>$_SESSION['avatar'],
      'id_tipo'=>$_SESSION['id_tipo'],
      'tipo_usuario'=>$_SESSION['tipo_usuario'],
    );
  } else {
    $json = array();
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}
else
if ($_POST['funcion'] == 'crear_usuario') {
  $nombre = $_POST['nombre'];
  $apellido = $_POST['apellido'];
  $email = $_POST['email'];
  $identificacion = $_POST['identificacion'];
  $contacto = $_POST['contacto'];
  $direccion = $_POST['direccion'];
  $contrasena = $_POST['contrasena'];
  $tipo = $_POST['tipo'];
  $usuario->Crear_Usuario($nombre, $apellido, $email, $identificacion, $contacto, $direccion, $contrasena, $tipo);
}
else
if ($_POST['funcion'] == 'editar_datos') {
  $id_usuario = $_POST['id_usuario'];
  $nombre = $_POST['nombre'];
  $apellidos = $_POST['apellidos'];
  $identificacion = $_POST['identificacion'];
  $email = $_POST['email'];
  $contacto = $_POST['contacto'];
  $direccion = $_POST['direccion'];
  $usuario->editar_datos($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion);
}
else
if ($_POST['funcion'] == 'editar_usuario') {
  $id_usuario = $_POST['id_usuario'];
  $nombre = $_POST['nombre'];
  $apellidos = $_POST['apellidos'];
  $identificacion = $_POST['identificacion'];
  $email = $_POST['email'];
  $contacto = $_POST['contacto'];
  $direccion = $_POST['direccion'];
  $contrasena = $_POST['contrasena'];
  $tipo = $_POST['tipo'];
  $usuario->editar_usuario($id_usuario, $nombre, $apellidos, $identificacion, $email, $contacto, $direccion, $contrasena, $tipo);
}
else
if ($_POST['funcion'] == 'buscar_usuario') {
  $json = array();
  $usuario->obtener_datos($_POST['dato']);
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'nombre' => $objeto->nombre,
      'apellidos' => $objeto->apellidos,
      'email' => $objeto->email,
      'identificacion' => $objeto->identificacion,
      'tipo' => $objeto->nombre_tipo,
      'contacto' => $objeto->telefono,
      'direccion' => $objeto->direccion
    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN USUARIO.JS
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
  // FIN CODIGO
}

if ($_POST['funcion'] == 'capturar_datos') {
  $json = array();
  $id_usuario = $_POST['id_usuario'];
  $usuario->obtener_datos($id_usuario);
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'nombre' => $objeto->nombre,
      'apellidos' => $objeto->apellidos,
      'identificacion' => $objeto->identificacion,
      'email' => $objeto->email,
      'contacto' => $objeto->telefono,
      'direccion' => $objeto->direccion
    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN USUARIO.JS
  $jsonstring = json_encode($json[0]);
  echo $jsonstring;
  // FIN CODIGO
}

if ($_POST['funcion'] == 'cambiar_clave') {
  $id_usuario = $_POST['id_usuario'];
  $clave_anterior = $_POST['clave_anterior'];
  $nueva_clave = $_POST['nueva_clave'];
  $usuario->cambio_clave($id_usuario, $clave_anterior, $nueva_clave);
}

if ($_POST['funcion'] == 'buscar_datos_usuarios') {
  $json = array();
  $usuario->buscador_usuarios();
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'id' => $objeto->id_usuario,
      'nombre' => $objeto->nombre,
      'apellidos' => $objeto->apellidos,
      'email' => $objeto->email,
      'identificacion' => $objeto->identificacion,
      'tipo' => $objeto->nombre_tipo,
      'contacto' => $objeto->telefono,
      'direccion' => $objeto->direccion,
      'contrasena' => $objeto->contrasena,
      'tipo_usuario' => $objeto->tipo_usu,
      'estatus' => $objeto->estatus_usu
    );
  }

  // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN USUARIO.JS
  $jsonstring = json_encode($json);
  echo $jsonstring;
  // FIN CODIGO
}

if ($_POST['funcion'] == 'inhabilitar') {
  $id = $_POST['id'];
  $usuario->inhabilitar($id);
}

if ($_POST['funcion'] == 'habilitar') {
  $id = $_POST['id'];
  $usuario->habilitar($id);
}

if ($_POST['funcion'] == 'eliminar') {
  $id = $_POST['id'];
  $usuario->eliminar($id);
}

if ($_POST['funcion'] == 'select_usuario') {
  $usuario->select_usuario();
  $json = array();
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'id_usuario' => $objeto->id_usuario,
      'nombre' => $objeto->nombre,
      'apellido' => $objeto->apellidos
    );
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}

if ($_POST['funcion'] == 'select_tecnico_usu') {
  $usuario->select_tecnico_usu();
  $json = array();
  foreach ($usuario->objetos as $objeto) {
    $json[] = array(
      'id' => $objeto->id_usuario,
      'nombre' => $objeto->nombre,
      'apellido' => $objeto->apellidos
    );
  }
  $jsonstring = json_encode($json);
  echo $jsonstring;
}

if ($_POST['funcion'] == 'total_usuarios') {

  $usuario->total_usuarios();

  foreach ($usuario->objetos as $objeto) {
  }
}

/*if ($_POST['funcion']=='verificar_password') {
    $identificacion = $_POST['identificacion'];
    $email = $_POST['email'];
    $usuario->verificar_password($identificacion,$email);
}*/
