$(document).ready(function () {
  

  // Evento Submit, Captura los datos diligenciados por el usuario en el formulario login.
  $('#form-login').submit(e => {
    // Obtiene el valor del campo ident del formulario login.
    let ident = $('#ident').val();
    // Obtener el valor del campo ident del formulario login.
    let pass = $('#pass').val();
    login(ident, pass);
    e.preventDefault();
  })

  // Función asincronico con el metodo await fetch.
  async function login(ident, pass) {
    // Declarar una funcion la cual es el parametro que va ir con el metodo asincronico.
    let funcion = "login";
    // Declarar una viable data, el await fetch recibe dos parametros la ruta y los atributos. 
    let data = await fetch('/gestion_tecnologias/controllers/cont_usuario.php', {
      // Atributos
      method: 'POST',
      // Indica de que forma voy a enviar parametros o variables junto con la ruta.
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      // Body seria los parametros que quiero enviar.
      body: 'funcion=' + funcion + '&&ident=' + ident + '&&pass=' + pass
    })
    // Manejo de errores en el servidor.
    // Cuando la conexión esta correcta.
    if (data.ok) {
      // Declarar una variable para recibir la respuesta del servidor.
      let response = await data.text();
      // Codificar la variable response_serv, el cual contiene un json string.
      try {
        let respuesta = JSON.parse(response);
        // Condicional para comparar el mensaje enviado por el json.
        if (respuesta.msg == 'success') {
          // Direccionar a la vista dashboard.
          location.href = "/gestion_tecnologias/views/admin/dashboard.php"
        } else if (respuesta.msg == 'error') {
          // Notificación del error.
          toastr.error('Oh No! Credenciales incorrectas', 'Error!')
          // Vaciar los campos del formulario login.
          $('#form-login').trigger('reset');
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Código: ' + data.status,
        })
        $('#form-login').trigger('reset');
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Código: ' + data.status,
      })
    }
  }

  // Función asincronica para verificar la sesión en curso.
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/gestion_tecnologias/controllers/cont_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          location.href = "/gestion_tecnologias/views/admin/dashboard.php"
          obtener_usuarios();
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'Al inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }

    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })


    }

  }
})