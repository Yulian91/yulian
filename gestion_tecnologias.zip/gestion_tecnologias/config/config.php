<?php
define("KEY","yam");
define("CODE","AES-128-ECB");
?>