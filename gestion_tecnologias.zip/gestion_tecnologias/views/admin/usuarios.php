<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/Template/header.php';
?>

<title>Gestión Usuarios</title><!-- Titulo de la pagina modulo gestionar areas -->

<title>SGME H&S - Modulo Usuarios</title><!-- Titulo del modulo gestionar areas -->

<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL AREA EN LA BASE DE DATOS -->
<div class="modal fade" id="crear_usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- id = Es la identificación del modal crear area -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Crear usuario</h3><!-- Titulo del modal crear datos del area -->
          <button data-dismiss="modal" aria-label="Close" class="close"><!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de la ciudad -->
          <form id="form-crear-usuario" class="row g-3"><!-- id = Es el identificador del formulario crear area -->
            <div class="col-md-6">
              <label for="nombre" class="form-label">Nombre</label>
              <input type="text" class="form-control" id="nombre" placeholder="Ingrese el nombre del usuario" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="apellido" class="form-label">Apellidos</label>
              <input type="text" class="form-control" id="apellido" placeholder="Ingrese los apellidos del usuario" required><!-- Caja de texto para ingresar el nuevo nombre del area --><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="email" class="form-label">Correo Electrónico</label>
              <input type="text" class="form-control" id="email" placeholder="Ingrese el correo electronico" required><!-- Caja de texto para ingresar el nuevo nombre del area --><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="identificacion" class="form-label">Identificación</label>
              <input type="number" class="form-control" id="identificacion" placeholder="Ingrese el No identificación" required><!-- Caja de texto para ingresar el nuevo nombre del area --><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="contacto" class="form-label">Contacto Telefonico</label>
              <input type="number" class="form-control" id="contacto" placeholder="Ingrese el No celular y/o telefono" required><!-- Caja de texto para ingresar el nuevo nombre del area --><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="direccion" class="form-label">Dirección</label>
              <input type="text" class="form-control" id="direccion" placeholder="Ingrese la dirección de residencia" required><!-- Caja de texto para ingresar el nuevo nombre del area --><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="contrasena" class="form-label">Contraseña</label>
              <input type="text" class="form-control" id="contrasena" placeholder="Ingrese la contraseña" required><!-- Caja de texto para ingresar el nuevo nombre del area --><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="tipo" class="form-label">Tipo Usuario</label>
              <select id="tipo" class="form-control" aria-label="Default select example" style="width: 100%;"><!-- Caja de texto para ingresar el nuevo nombre del area --><!-- Caja de texto para ingresar el nuevo nombre del area -->
                <option selected>Seleccione el tipo de usuario</option>
                <option value="2">Administrador</option>
                <option value="3">Tecnico</option>
                <option value="4">Cliente</option>
              </select>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del area -->
          <button type="button" id="btn_limpiar_1" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del area -->
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL AREA -->
<div class="modal fade" id="editar_usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- id = Es la identificación del modal crear area -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Editar usuario</h3><!-- Titulo del modal crear datos del area -->
          <button data-dismiss="modal" aria-label="Close" class="close"><!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <!-- Formulario para ingresar los datos de la ciudad -->
          <form id="form-editar-usuario" class="row g-3"><!-- id = Es el identificador del formulario editar area -->
            <div class="col-md-6">
              <input type="hidden" id="id_usuario">
              <label for="nombre" class="form-label">Nombre</label>
              <input type="text" class="form-control" id="nombre_usu" placeholder="Ingrese el nombre" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="apellido" class="form-label">Apellidos</label>
              <input type="text" class="form-control" id="apellido_usu" placeholder="Ingrese los apellidos" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="email" class="form-label">Correo Electrónico</label>
              <input type="text" class="form-control" id="email_usu" placeholder="Ingrese el correo electronico" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="identificacion" class="form-label">Identificación</label>
              <input type="number" class="form-control" id="identificacion_usu" placeholder="Ingrese el No identificación" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="contacto" class="form-label">Contacto Telefonico</label>
              <input type="number" class="form-control" id="contacto_usu" placeholder="Ingrese el No celular y/o telefono" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="direccion" class="form-label">Dirección</label>
              <input type="text" class="form-control" id="direccion_usu" placeholder="Ingrese la dirección de residencia" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="contrasena" class="form-label">Contraseña</label>
              <input type="text" class="form-control" id="contrasena_usu" placeholder="Ingrese la contraseña" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
            <div class="col-md-6">
              <label for="tipo" class="form-label">Tipo Usuario</label>
              <select id="tipo_usu" class="form-control" aria-label="Default select example" style="width: 100%;"><!-- Caja de texto para ingresar el nuevo nombre del area -->
                <option selected>Seleccione el tipo de usuario</option>
                <option value="2">Administrador</option>
                <option value="3">Tecnico</option>
                <option value="4">Cliente</option>
              </select>
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del area -->
          <button type="button" id="btn_limpiar_2" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del area -->
        </div>
        </form>
        <!-- Fin del formulario -->
      </div>
    </div>
  </div>
</div>
<!-- FIN CODIGO MODAL -->

<!-- CONTENIDO DEL MODULO GESTIONAR AREAS -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestionar Usuarios</h1><!-- Titulo del Modulo gestionar areas -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Gestionar usuarios</li><!-- Este item nos indica que nos encontramos en el modulo gestionar areas -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR AREAS -->
  <section>
    <div class="container-fluid">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Buscar usuarios</h3><!-- Titulo del buscador -->
          <div class="input-group">
            <input type="text" id="buscar-usuarios" class="form-control float-left" placeholder="Ingresar el nombre del usuario"><!-- Este campo es para buscar el nombre de una area especifica -->
            <div class="input-group-append">
              <button class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_usuario">Crear usuarios</button><!-- Este boton es para crear una nueva area. Al dar clic se abrira el modal crear area -->
          </div>
        </div>
        <div class="card-body p-0 table-responsive">
          <!-- Esta es la tabla de los datos de las areas registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
          <table class="table table-over text-nowrap">
            <thead class="table-info"><!-- Este es la clase de la tabla la cual define el color de la misma -->
              <tr><!-- Estos son los titulos de la tabla -->
                <th>Nombre</th>
                <th>Apellido</th>
                <th>@E-mail</th>
                <th>Identificación</th>
                <th>Tipo Usuario</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
              <tbody class="table-active" id="usuarios"><!-- id = Es el identificador de la tabla ciudades -->
              </tbody>
          </table>
          <!-- Fin de la tabla -->
        </div>
        <div class="card-footer"> 
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR AREAS -->

<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/Template/footer.php';
?>

<!-- Esta es la conexión del archivo usuarios.php con el gestion_usuario.js -->
<script src="/gestion_tecnologias/js/usuarios.js"></script>