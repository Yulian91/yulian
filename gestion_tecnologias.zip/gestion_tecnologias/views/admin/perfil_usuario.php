<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/Template/header.php';
?>

<title>Soft. Biomedíca | Perfil Usuario</title>

<div class="content-wrapper" style="min-height: 600px;">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Perfil Usuario</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="/gestion_tecnologias/views/admin/dashboard.php">Inicio</a></li>
            <li class="breadcrumb-item active">Perfil Usuario</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="card">
      <div id="card_1" class="card-body">
      </div>
    </div>
  </section>

  <!-- Modal Editar Usuario -->
  <div class="modal fade" id="editar_usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title">Modificar datos del usuario</h3>
            <button data-dismiss="modal" aria-label="Close" class="close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="card-body">
            <form id="form-editar-usuario" enctype="multipart/form-data" class="row g-3">
              <div class="col-md-6">
                <input type="hidden" id="id_usuario">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="nombre_usu" placeholder="Ingrese el nombre del usuario" required>
              </div>
              <div class="col-md-6">
                <label for="apellido" class="form-label">Apellidos</label>
                <input type="text" class="form-control" id="apellido_usu" placeholder="Ingrese los apellidos del usuario" required>
              </div>
              <div class="col-md-6">
                <label for="email" class="form-label">Correo Electrónico</label>
                <input type="text" class="form-control" id="email_usu" placeholder="Ingrese el correo electronico" required>
              </div>
              <div class="col-md-6">
                <label for="identificacion" class="form-label">Identificación</label>
                <input type="number" class="form-control" id="identificacion_usu" placeholder="Ingrese el # identificación" required>
              </div>
              <div class="col-md-6">
                <label for="contacto" class="form-label">Contacto Telefonico</label>
                <input type="number" class="form-control" id="contacto_usu" placeholder="Ingrese el # celular y/o telefono" required>
              </div>
              <div class="col-md-6">
                <label for="direccion" class="form-label">Dirección Residencia</label>
                <input type="text" class="form-control" id="direccion_usu" placeholder="Ingrese la dirección de residencia" required>
              </div>
              <div class="col-md-6">
                <label for="contrasena" class="form-label">Contraseña</label>
                <input type="text" class="form-control" id="contrasena_usu" placeholder="Ingrese la contraseña" required>
              </div>
              <div class="col-md-6">
                <label for="tipo" class="form-label">Tipo Usuario</label>
                <select id="tipo_usu" class="form-control" aria-label="Default select example" style="width: 100%;">
                  <option selected>Seleccione el tipo de usuario</option>
                  <option value="1">Root</option>
                  <option value="2">Administrador</option>
                  <option value="3">Tecnico</option>
                  <option value="4">Cliente</option>
                </select>
              </div>
              <div class="col-md-12">
                <label for="contacto" class="form-label">Imagen Perfil</label>
                <input type="number" class="form-control" id="contacto_usu" placeholder="Ingrese el # celular y/o telefono" required>
              </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-outline-success btn-circle btn-lg"><i class="fas fa-check"></i></button>
            <button type="button" id="" data-dismiss="modal" class="btn btn-outline-secondary btn-circle btn-lg"><i class="fas fa-arrow-left"></i></button>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>

</div>

<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/Template/footer.php';
?>
<script src="/gestion_tecnologias/views/admin/perfil_usuario.js"></script>