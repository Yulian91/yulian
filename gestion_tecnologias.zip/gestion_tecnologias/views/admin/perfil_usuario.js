$(document).ready(function () {
  verificar_session();
  obtener_usuario();

  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/gestion_tecnologias/controllers/cont_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {

        } else {
          location.href = "/gestion_tecnologias/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'Al inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }

    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }

  async function obtener_usuario() {
    let funcion = "obtener_usuario";
    let data = await fetch('/gestion_tecnologias/controllers/cont_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let usuario = JSON.parse(response);
        console.log(usuario);
        let template = `
        <div class="col-md-12">
          <div class="form-group">
            <img src="/gestion_tecnologias/Util/img/${usuario.avatar}" width="100" height="100" class="img-fluid img-circle">
          </div>
          <hr>
          <div class="form-group">
            <label class="col-sm-2 control-label">Nombre Usuario :</label>
            <label style="text-align:left" class="col-sm-8 control-label">${usuario.nombre}</label>
          </div>
          <hr>
          <div class="form-group">
            <label class="col-sm-2 control-label">Apellido :</label>
            <label style="text-align:left" class="col-sm-8 control-label">${usuario.apellido}</label>
          </div>
          <hr>
          <div class="form-group">
            <label class="col-sm-2 control-label">Identificación :</label>
            <label style="text-align:left" class="col-sm-8 control-label">${usuario.identificacion}</label>
          </div>
          <hr>
          <div class="form-group">
            <label class="col-sm-2 control-label">Correo Electronico :</label>
            <label style="text-align:left" class="col-sm-8 control-label">${usuario.email}</label>
          </div>
          <hr>
          <div class="form-group">
            <label class="col-sm-2 control-label">Tipo Usuario :</label>
            <label style="text-align:left" class="col-sm-8 control-label">${usuario.tipo_usuario}</label>
          </div>
          <hr>
          <div class="form-group">
            <label class="col-sm-2 control-label">Estado :</label>
            <label style="text-align:left" class="col-sm-8 control-label">${usuario.estado}</label>
          </div>
        </div>
        <hr>
        <div class="row">
          <div class="col-md-12">
            <div class="col-md-6">
              <div class="col-sm-offset-2 col-sm-10">
                <button class="btn btn-primary" title="Editar los datos del usuario" type="button" data-toggle="modal" data-target="#editar_usuario">
                  <i class="fas fa-pencil-alt"><span>Modificar</span></i>
                </button>
              </div>
            </div>
          </div>
        </div>`;

        $("#card_1").html(template);

      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'Error, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }

    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'Error, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }

})
    /*let español = {
"autoFill": {
  "cancel": "Cancelar"
},
"buttons": {
  "collection": "Coleccion",
  "colvis": "Columna Visible",
  "colvisRestore": "Restaurar Columnas Visibles",
  "copy": "Copiar",
  "copyKeys": "presiones inicio + c para copiar ka infrocion de la tabla.  click en este mensaje para salir o esc.",
  "copySuccess": {
      "_": "Copiado con exito",
      "1": "Fila copiada con exito"
  },
  "copyTitle": "Tabla Copiada",
  "createState": "Crear estado",
  "pageLength": {
      "_": "ver %d filas",
      "-1": "Ver todas las Filas",
      "1": "Ver solo una fila"
  },
  "print": "Impresion",
  "removeAllStates": "Remover todos los estados",
  "removeState": "Remover",
  "renameState": "Renombrar",
  "savedStates": "Guardar Estado",
  "stateRestore": "Restaurar %d",
  "updateState": "Actualizar",
  "csv": "CSV",
  "excel": "Excel",
  "pdf": "PDF"
},
"datetime": {
  "hours": "hora",
  "minutes": "minuto",
  "months": {
      "0": "Enero",
      "1": "Febrero",
      "10": "Noviembre",
      "11": "Diciembre",
      "2": "Marzo",
      "3": "Abril",
      "4": "Mayo",
      "5": "Junio",
      "6": "Julio",
      "7": "Agosto",
      "8": "Septiembre",
      "9": "Octubre"
  },
  "next": "siguiente",
  "previous": "anterior",
  "seconds": "segundo",
  "weekdays": [
      "Dom",
      "Lun",
      "Mar",
      "Mir",
      "Jue",
      "Vie",
      "sab"
  ],
  "unknown": "desconocido",
  "amPm": [
      "am",
      "pm"
  ]
},
"editor": {
  "close": "Cerrar",
  "create": {
      "button": "Nuevo",
      "submit": "Crear",
      "title": "Crerar nueva entrada"
  },
  "edit": {
      "button": "Editar",
      "submit": "Actualizar",
      "title": "Editar Registro"
  },
  "error": {
      "system": "a ocurrido un error "
  },
  "multi": {
      "restore": "revertir cambios",
      "info": "Los elementos seleccionados contienen diferentes valores para esta entrada. Para editar y configurar todos los elementos de esta entrada en el mismo valor, haga clic o toque aquí, de lo contrario, conservar sus valores individuales.",
      "noMulti": "Múltiples valores"
  },
  "remove": {
      "button": "Borrar",
      "confirm": {
          "_": "esta seguro de eliminar %d los registros",
          "1": "esta seguro de eliminar el registro"
      },
      "submit": "Borrar",
      "title": "Borrar"
  }
},
"emptyTable": "Tabla Vacia",
"info": "informacion",
"infoEmpty": "Sin informacion",
"lengthMenu": "Entradas",
"loadingRecords": "Cargando...",
"paginate": {
  "first": "primero",
  "last": "ultimo",
  "next": "siguiente",
  "previous": "anterior"
},
"processing": "Procesando",
"search": "Busqueda",
"searchBuilder": {
  "add": "agragar condicion",
  "button": {
      "_": "Creador de búsquedas (%d)",
      "0": "Creador de búsquedas"
  },
  "clearAll": "Quitar filtro",
  "condition": "Condicion",
  "data": "Datos",
  "deleteTitle": "eliminar regla",
  "logicAnd": "Y",
  "logicOr": "O",
  "value": "Valor"
},
"searchPanes": {
  "clearMessage": "Borrar Filtro",
  "collapseMessage": "desplegar todo",
  "emptyPanes": "No hay informacion",
  "loadMessage": "Cargando informacion",
  "showMessage": "Mostrar todos",
  "title": "Filtros Activos - %d"
},
"searchPlaceholder": "Busqueda en tabla",
"select": {
  "cells": {
      "_": "%d celdas seleccionadas",
      "1": "1 celda seleccionada"
  },
  "columns": {
      "_": "%d columnas seleccionadas",
      "1": "1 columna seleccionada"
  }
},
"zeroRecords": "No se encontro informacion"
 
}*/