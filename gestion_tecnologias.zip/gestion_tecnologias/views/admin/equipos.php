<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/Template/header.php';
?>

<div class="content-wrapper" style="min-height: 600px;">

  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Gestión de Equipos</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="/gestion_tecnologias/views/admin/dashboard.php">Inicio</a></li>
            <li class="breadcrumb-item active">Equipos Biomedicos</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Equipos Biomedicos</h3>
      </div>
      <div class="card-body">
        <table id="equipos" class="table table-over">
          <thead class="table-success">
            <tr>
              <th width="100%">Nombre</th>
              
            </tr>
          </thead>
          <tbody>
          </tbody>
        </table>
      </div>
      <div class="card-footer">Buscar equipos</div>
    </div>
  </section>

  <!--<section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card-body">
            <div class="card-body p-0 table-responsive">
              <table id="equipos" class="table table-over text-nowrap">
                <thead class="table-success">
                  <tr>
                    <th>Nombre</th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
          <div class="card">
              <div class="card-header">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a href="#cronograma_matto" class="nav-link active" data-toggle="tab">Cronograma mantenimiento</a></li>
                  <li class="nav-item"><a href="#list_matto" class="nav-link" data-toggle="tab">Listado mattos programados</a></li>
                </ul>
              </div>
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="cronograma_matto">
                     THE CALENDAR
                    <div id="calendar" class="fc fc-media-screen fc-direction-ltr fc-theme-bootstrap"></div>
                  </div>
                  <div class="tab-pane" id="list_matto">
                    <div class="card card-info">
                      <div class="card-header">
                        <div class="card-title">Listado de mantenimientos programados</div>
                      </div>
                      <div class="card-body p-0 table-responsive">
                        <table id="insumos_med" class="table table-over text-nowrap">
                          <thead class="table-success">
                            <tr>
                              <th>N.</th>
                              <th>Equipo</th>
                              <th>Serie</th>
                              <th>Actividad</th>
                              <th>Fecha Inicio</th>
                              <th>Fecha Final</th>
                              <th>Sede</th>
                              <th>Descripcíon</th>
                              <th>Estado</th>
                              <th>Acciones</th>
                            </tr>
                          </thead>
                          <tbody class="table-active" id="listado_matto">
                          </tbody>
                        </table>
                      </div>
                      <div class="card-footer"></div>
                    </div>
                  </div>
                </div>
              </div>
          
        </div>
       
      </div>
      
    </div>
    
  </section>-->

</div>

<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/gestion_tecnologias/Template/footer.php';
?>
<script src="/gestion_tecnologias/views/admin/equipos.js"></script>