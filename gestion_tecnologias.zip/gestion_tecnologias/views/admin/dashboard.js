$(document).ready(function () {
  verificar_session();
  loader();

  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/gestion_tecnologias/controllers/cont_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          close_loader();
        } else {
          location.href = "/gestion_tecnologias/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'Al inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }

    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }

  function loader(mensaje) {
    if (mensaje == '' || mensaje == null){
      mensaje = "Cargando Datos, por favor espere..";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: mensaje,
      showConfirmButton: false,
    })
  }

  function close_loader(mensaje,tipo) {
    if (mensaje == '' || mensaje == null){
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: mensaje,
        showConfirmButton: false,
      })
    }

  }

})