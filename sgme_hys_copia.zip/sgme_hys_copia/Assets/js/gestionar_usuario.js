$(document).ready(function () {
  var funcion = '';
  buscar_datos();

  // FUNCION PARA CREAR NUEVOS USUARIOS 
  $('#form-crear-usuario').submit(e => {
    let nombre = $('#nombre').val();
    let apellido = $('#apellido').val();
    let email = $('#email').val();
    let identificacion = $('#identificacion').val();
    let contacto = $('#contacto').val();
    let direccion = $('#direccion').val();
    let contrasena = $('#contrasena').val();
    let tipo = $('#tipo').val()

    funcion = 'crear_usuario';
    $.post('/sgme_hys/Controllers/control_usuario.php', { nombre, apellido, email, identificacion, contacto, direccion, contrasena, tipo, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El usuario ' + nombre + ' se creo correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-usuario').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          '¡No fue creado!',
          'El No de id ' + identificacion + ' del usuario ya existe',
          'error'
        )
        $('#form-crear-usuario').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN

  // FUNCION PARA EDITAR LOS USUARIOS REGISTRADOS EN LA BASE DE DATOS
  $('#form-editar-usuario').submit(e => {
    let id_usuario = $('#id_usuario').val();
    let nombre = $('#nombre_usu').val();
    let apellidos = $('#apellido_usu').val();
    let email = $('#email_usu').val();
    let identificacion = $('#identificacion_usu').val();
    let contacto = $('#contacto_usu').val();
    let direccion = $('#direccion_usu').val();
    let contrasena = $('#contrasena_usu').val();
    let tipo = $('#tipo_usu').val();

    funcion = 'editar_usuario';
    $.post('/sgme_hys/Controllers/control_usuario.php', { id_usuario, nombre, apellidos, identificacion, email, contacto, direccion, contrasena, tipo, funcion }, (response) => {
      if (response == 'update_usu') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del usuario ' + nombre + ' se actualizaron correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-equipo').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          'No fue actualizado!',
          'El id ' + identificacion + ' del usuario ya existe.',
          'error'
        )
        $('#form-crear-cliente').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN

  function buscar_datos(consulta) {
    funcion = 'buscar_datos_usuarios';
    $.post('/sgme_hys/Controllers/control_usuario.php', { consulta, funcion }, (response) => {
      const usuarios = JSON.parse(response);
      let template = '';
      usuarios.forEach(usuario => {
        template += `
          <tr idusu="${usuario.id}" nombreusu="${usuario.nombre}" apellidousu="${usuario.apellidos}" emailusu="${usuario.email}" 
            identificacionusu="${usuario.identificacion}" contactousu="${usuario.contacto}" direccionusu="${usuario.direccion}" 
            contrasenausu="${usuario.contrasena}" tipousu="${usuario.tipo_usuario}">
            <td>${usuario.nombre}</td>
            <td>${usuario.apellidos}</td>
            <td>${usuario.email}</td>
            <td>${usuario.identificacion}</td>
            <td>${usuario.contacto}</td>
            <td>${usuario.direccion}</td>
            <td>${usuario.contrasena}</td>
            <td> <h1 class="badge badge-info">${usuario.tipo}</h1> </td>
              <div class="text-right">`;
        if (usuario.estatus == 'ACTIVO') {
          template += `
                    <td><h1 class="badge badge-info">${usuario.estatus}</h1></td>
                  `;
        } else {
          template += `
                    <td><h1 class="badge badge-danger">${usuario.estatus}</h1></td>
                  `;
        }
        template += `
              </div>
              <td>
                <div class="text-right">`;
        if (usuario.tipo_usuario != 1) {
          if (usuario.estatus == 'ACTIVO') {
            template += `
                      <button class="editar btn btn-primary" title="Editar los datos del usuario" type="button" data-toggle="modal" data-target="#editar_usuario">
                        <i class="fas fa-pencil-alt"></i>
                      </button> 
                      <button class="inhabilitar btn btn-danger" title="Inactivar los datos del usuario">
                        <i class="fas fa-times"></i>
                      </button>
                    `;
          } else if (usuario.estatus == 'INACTIVO') {
            template += `
                      <button class="habilitar btn btn-primary" title="Activar los datos del usuario">
                        <i class="fas fa-check-square"></i>
                      </button>
                      <button class="eliminar btn btn-danger" title="Eliminar los datos del usuario">
                        <i class="fas fa-trash-alt"></i>
                      </button>
                    `;
          }
        }
        template += `
                </div>
              </td>
          </tr>
        `;
      })
      $('#usuarios').html(template);
    });
  }

  $(document).on('keyup', '#buscar-usuarios', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });

  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    $('#id_usuario').val(id);
    $('#nombre_usu').val(nombre);
    $('#apellido_usu').val(apellidos);
    $('#email_usu').val(email);
    $('#identificacion_usu').val(identificacion);
    $('#contacto_usu').val(contacto);
    $('#direccion_usu').val(direccion);
    $('#contrasena_usu').val(contrasena);
    $('#tipo_usu').val(tipo);

  });

  $(document).on('click', '.inhabilitar', (e) => {
    funcion = "inhabilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    Swal.fire({
      title: '¿Desea inactivar el usuario ' + nombre + ' ' + apellidos + '?',
      text: "El usuario sera inactivado, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_usuario.php', { id, funcion }, (response) => {
          if (response == 'inactivado') {
            Swal.fire(
              'Inactivado!',
              'El usuario ' + nombre + ' ' + apellidos + ' fue inactivado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue inactivado!',
              'El usuario ' + nombre + ' ' + apellidos + ' no fue inactivado.',
              'error'
            )
          }
        });
      }
    })
  });

  $(document).on('click', '.habilitar', (e) => {
    funcion = "habilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    Swal.fire({
      title: '¿Desea activar el usuario ' + nombre + ' ' + apellidos + '?',
      text: "Los datos del usuario seran activados!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_usuario.php', { id, funcion }, (response) => {
          if (response == 'activado') {
            Swal.fire(
              'Activado!',
              'El usuario ' + nombre + ' ' + apellidos + ' fue activado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue activado!',
              'El usuario ' + nombre + ' ' + apellidos + ' no fue activado.',
              'error'
            )
          }
        });
      }
    })
  });

  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement.parentElement;
    const id = $(elemento).attr('idusu');
    const nombre = $(elemento).attr('nombreusu');
    const apellidos = $(elemento).attr('apellidousu');
    const email = $(elemento).attr('emailusu');
    const identificacion = $(elemento).attr('identificacionusu');
    const contacto = $(elemento).attr('contactousu');
    const direccion = $(elemento).attr('direccionusu');
    const contrasena = $(elemento).attr('contrasenausu');
    const tipo = $(elemento).attr('tipousu');
    Swal.fire({
      title: '¿Desea eliminar del usuario ' + nombre + ' ' + apellidos + '?',
      text: "¡Los datos del usuario seran borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_usuario.php', { id, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              '¡Borrado!',
              'Los datos del usuario ' + nombre + ' ' + apellidos + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue borrado!',
              'Los datos del usuario ' + nombre + ' ' + apellidos + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });

  $(document).on('click', '#btn_limpiar_1', (e) => {
    $('#form-crear-usuario').trigger('reset');
    buscar_datos();
  });

  $(document).on('click', '#btn_limpiar_2', (e) => {
    $('#form-editar-usuario').trigger('reset');
    buscar_datos();
  });

})