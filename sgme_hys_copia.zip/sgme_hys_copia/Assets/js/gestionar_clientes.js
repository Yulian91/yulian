$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  buscar_datos(); /** Inicializar la funcion buscar datos */

  // FUNCION PARA ENVIAR LOS DATOS DEL CLIENTE Y GUARDARLOS EN LA BASE DE DATOS
  $('#form-crear-cliente').submit(e => {
    let nombre = $('#nombre').val();
    let nit = $('#nit').val();
    let telefono = $('#telefono').val();
    let tipo_contrato = $('#tipo_contrato').val();
    let num_contrato = $('#num_contrato').val();
    let direccion = $('#direccion').val();
    let contacto = $('#name_contacto').val();
    let email = $('#email').val();

    funcion = 'crear_cliente';
    $.post('../../Controllers/control_cliente.php', { nombre, nit, telefono, tipo_contrato, num_contrato, direccion, contacto, email, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El cliente fue agregado correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-cliente').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          'No fue agregado!',
          'El ' + nit + ' del cliente ya existe.',
          'error'
        )
        $('#form-crear-cliente').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN

  // FUNCION PARA EDITAR LOS DATOS DEL CLIENTE REGISTRADOS EN LA BASE DE DATOS
  $('#form-editar-cliente').submit(e => {
    let id_cliente = $('#id_cliente').val();
    let nombre = $('#nombre_cli').val();
    let nit = $('#nit_cli').val();
    let telefono = $('#telefono_cli').val();
    let tipo_contrato = $('#tipo_contrato_cli').val();
    let num_contrato = $('#no_contrato_cli').val();
    let direccion = $('#direccion_cli').val();
    let contacto = $('#name_contacto_cli').val();
    let email = $('#email_cli').val();

    funcion = 'editar_cliente';
    $.post('../../Controllers/control_cliente.php', { id_cliente, nombre, nit, telefono, tipo_contrato, num_contrato, direccion, contacto, email, funcion }, (response) => {
      console.log(response);
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del cliente ' + nombre + ' se actualizaron correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-cliente').trigger('reset');
        buscar_datos();
      } else {
        Swal.fire(
          'No fue actualizado!',
          'Los datos del cliente ' + nombre + ' no se actualizaron.',
          'error'
        )
        $('#form-crear-cliente').trigger('reset');
      }
    });
    e.preventDefault();
  });
  // FIN

  // FUNCION PARA BUSCAR LOS DATOS DE LOS CLIENTES REGISTRADOS EN LA BASE DE DATOS
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_cliente';
    $.post('../../Controllers/control_cliente.php', { consulta, funcion }, (response) => {
      const clientes = JSON.parse(response);
      let template = '';
      clientes.forEach(cliente => {
        template += `
            <tr idcliente="${cliente.id_cliente}" nombrecliente="${cliente.nombre_cliente}" nitcliente="${cliente.nit_cliente}" telefonocliente="${cliente.telefono_cliente}"
              tipocontrato="${cliente.tipo_contrato}" numcontrato="${cliente.num_contrato}" direccioncliente="${cliente.direccion_cliente}" contacto="${cliente.nombre_contacto}" 
              emailcliente="${cliente.email_cliente}">
              <td>${cliente.nombre_cliente}</td>
              <td>${cliente.nit_cliente}</td>
              <td>${cliente.telefono_cliente}</td>
              <td>${cliente.tipo_contrato}</td>
              <td>${cliente.num_contrato}</td>
              <td>${cliente.direccion_cliente}</td>
              <td>${cliente.email_cliente}</td>
              <td>${cliente.nombre_contacto}</td>
                <div class="text-right">`;
                  if (cliente.estatus == 'ACTIVO') {
                    template += `
                      <td><h1 class="badge badge-info">${cliente.estatus}</h1></td>
                      <td>
                        <button class="editar btn btn-primary" title="Editar los datos del cliente" type="button" data-toggle="modal" data-target="#editar_cliente">
                          <i class="fas fa-pencil-alt"></i>
                        </button>
                        <button class="inhabilitar btn btn-danger" title="Inactivar los datos del cliente">
                          <i class="fas fa-times"></i>
                        </button>
                      </td>
                    `;
                  } else {
                    template += `
                      <td><h1 class="badge badge-danger">${cliente.estatus}</h1></td>
                      <td>
                        <button class="habilitar btn btn-primary" title="Activar los datos del cliente">
                          <i class="fas fa-check-square"></i>
                        </button>
                        <button class="eliminar btn btn-danger" title="Eliminar definitivamente los datos del cliente">
                          <i class="fas fa-trash-alt"></i>
                        </button>
                      </td>
                    `;
                  }
                  template += `
                </div>
            </tr>
          `;
                })
      $('#clientes').html(template);
    });
  }
  // FIN

  // FUNCION PARA FILTRAR LOS DATOS DEL CLIENTE SEGUN EL PARAMETRO
  $(document).on('keyup', '#buscar_cliente', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN

  // FUNCION PARA LLAMAR LOS DATOS DEL CLIENTE
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const contacto = $(elemento).attr('contacto');
    const email = $(elemento).attr('emailcliente');
    $('#id_cliente').val(id);
    $('#nombre_cli').val(nombre);
    $('#nit_cli').val(nit);
    $('#telefono_cli').val(telefono);
    $('#tipo_contrato_cli').val(tipo_contrato);
    $('#no_contrato_cli').val(num_contrato);
    $('#direccion_cli').val(direccion);
    $('#name_contacto_cli').val(contacto);
    $('#email_cli').val(email);
  });
  // FIN

  // FUNCION PARA INACTIVAR LOS DATOS DEL CLIENTE
  $(document).on('click', '.inhabilitar', (e) => {
    funcion = "inhabilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const usuario = $(elemento).attr('usuario');
    const email = $(elemento).attr('emailcliente');

    Swal.fire({
      title: '¿Desea inactivar el cliente ' + nombre + '?',
      text: "El cliente sera inactivado, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cliente.php', { id, funcion }, (response) => {
          if (response == 'inactivado') {
            Swal.fire(
              'Inactivado!',
              'El cliente ' + nombre + ' fue inactivado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue inactivado!',
              'El cliente ' + nombre + ' no fue inactivado.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN
  
  // FUNCION PARA ACTIVAR LOS DATOS DEL CLIENTE
  $(document).on('click', '.habilitar', (e) => {
    funcion = "habilitar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const usuario = $(elemento).attr('usuario');
    const email = $(elemento).attr('emailcliente');

    Swal.fire({
      title: '¿Desea activar el cliente ' + nombre + '?',
      text: "Los datos del cliente seran activados!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cliente.php', { id, funcion }, (response) => {
          if (response == 'activo') {
            Swal.fire(
              'Activado!',
              'Los datos del cliente ' + nombre + ' fueron activados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue activado!',
              'Los datos del cliente ' + nombre + ' no fueron activados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN

  // FUNCION PARA ELIMINAR LOS DATOS DEL CLIENTE
  $(document).on('click', '.eliminar', (e) => {
    funcion = "eliminar";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('idcliente');
    const nombre = $(elemento).attr('nombrecliente');
    const nit = $(elemento).attr('nitcliente');
    const telefono = $(elemento).attr('telefonocliente');
    const tipo_contrato = $(elemento).attr('tipocontrato');
    const num_contrato = $(elemento).attr('numcontrato');
    const direccion = $(elemento).attr('direccioncliente');
    const usuario = $(elemento).attr('usuario');
    const email = $(elemento).attr('emailcliente');

    Swal.fire({
      title: 'Desea eliminar el cliente ' + nombre + '?',
      text: "Los datos del cliente seran borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cliente.php', { id, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              'Borrado!',
              'Los datos del cliente ' + nombre + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue borrado!',
              'Los datos del cliente ' + nombre + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN

  // FUNCION PARA LIMPIAR EL FORMULARIO CREAR CLIENTE
  $(document).on('click', '#btn_limpiar_1', (e) => {
    $('#form-crear-cliente').trigger('reset');
    buscar_datos();
  });
  // FIN

  // FUNCION PARA LIMPIAR EL FORMULARIO EDITAR CLIENTE
  $(document).on('click', '#btn_limpiar_2', (e) => {
    $('#form-editar-cliente').trigger('reset');
    buscar_datos();
  });
  // FIN

})