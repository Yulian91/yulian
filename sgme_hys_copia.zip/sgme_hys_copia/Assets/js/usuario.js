$(document).ready(function () {
  var funcion = '';
  var id_usuario = $('#id_usuario').val();
  var edit = false;
  buscar_usuario(id_usuario);
  mostrarPassword1();

  function buscar_usuario(dato) {
    funcion = 'buscar_usuario';
    $.post('/sgme_hys/Controllers/control_usuario.php', { dato, funcion }, (response) => {
      let nombre = '';
      let apellidos = '';
      let email = '';
      let identificacion = '';
      let tipo = '';
      let contacto = '';
      let direccion = '';
      const usuario = JSON.parse(response);
      nombre += `${usuario.nombre}`;
      apellidos += `${usuario.apellidos}`;
      email += `${usuario.email}`;
      identificacion += `${usuario.identificacion}`;
      tipo += `${usuario.tipo}`;
      contacto += `${usuario.contacto}`;
      direccion += `${usuario.direccion}`;
      $('#nombre').html(nombre);
      $('#apellidos').html(apellidos);
      $('#identificacion').html(identificacion);
      $('#tipo_usu').html(tipo);
      $('#email').html(email);
      $('#telefono').html(contacto);
      $('#direccion').html(direccion);
    })
  }

  $(document).on('click', '.edit', (e) => {
    funcion = 'capturar_datos';
    $.post('/sgme_hys/Controllers/control_usuario.php', { funcion, id_usuario }, (response) => {
      const usuario = JSON.parse(response);
      $('#nombre_usu').val(usuario.nombre);
      $('#apellidos_usu').val(usuario.apellidos);
      $('#identificacion_usu').val(usuario.identificacion);
      $('#email_usu').val(usuario.email);
      $('#contacto_usu').val(usuario.contacto);
      $('#direccion_usu').val(usuario.direccion);

      $('#form-usuario').submit(e => {
        let nombre = $('#nombre_usu').val();
        let apellidos = $('#apellidos_usu').val();
        let identificacion = $('#identificacion_usu').val();
        let email = $('#email_usu').val();
        let contacto = $('#contacto_usu').val();
        let direccion = $('#direccion_usu').val();
        funcion = 'editar_datos';
        $.post('/sgme_hys/Controllers/control_usuario.php', { funcion, id_usuario, nombre, apellidos, identificacion, email, contacto, direccion }, (response) => {
          if (response == 'update_datos') {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: 'Los datos del usuario ' + nombre + ' ' + apellidos + ' se actualizaron correctamente',
              showConfirmButton: false,
              timer: 1500
            })
            $('#form-usuario').trigger('reset');
            edit = false;
            buscar_usuario(id_usuario);
          }
        })
        e.preventDefault();
      });
    })
  });

  $('#form-clave').submit(e => {
    let clave_anterior = $('#clave_anterior').val();
    let nueva_clave = $('#nueva_clave').val();
    funcion = 'cambiar_clave';
    $.post('/sgme_hys/Controllers/control_usuario.php', { id_usuario, clave_anterior, nueva_clave, funcion }, (response) => {
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Se cambio la contraseña correctamente',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-clave').trigger('reset');
      }
      if (response == 'noupdate') {
        Swal.fire(
          'La contraseña no se puede cambiar',
          'Intenta nuevamente',
          'error'
        )
        $('#form-clave').trigger('reset');
      }
    })
    e.preventDefault();
  });

  $(document).on('click', '#btn_limpiar', (e) => {
    $('#form-clave').trigger('reset');
  });

  function mostrarPassword1() {
    var mostrar = document.getElementById("clave_anterior");
    if (mostrar.type == "password") {
      mostrar.type = "text";
      $('.icon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
    } else {
      mostrar.type = "password";
      $('.icon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
    }
  }

})