$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  //var editar_equipo = new bootstrap.Modal(document.getElementById('editar_equipo'));
  //var crear_inventario = new bootstrap.Modal(document.getElementById('crear_inventario'));
  buscar_datos(); /** Inicializar la funcion buscar datos */


  // FORMULARIO PARA CREAR EL EQUIPO EN LA BASE DE DATOS
  $('#form-crear-equipo').submit(e => {
    let nombre_equipo = $('#equipo').val();
    let n_activo = $('#n_activo').val();
    let marca = $('#marca').val();
    let modelo = $('#modelo').val();
    let serie = $('#serie').val();
    let pro_terc = $('#pro_terc').val();
    let estado = $('#estado').val();
    let garantia = $('#garantia').val();

    funcion = 'crear_equipo';
    $.post('../../Controllers/control_equipo.php', { nombre_equipo, n_activo, marca, modelo, serie, pro_terc, estado, garantia, funcion }, (response) => {
      if (response == 'add') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'El equipo ' + nombre_equipo + ' fue creado correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-crear-equipo').trigger('reset');
        buscar_datos();
      }
      if (response == 'noadd') {
        Swal.fire(
          '¡No fue creado!',
          'El equipo con la serie ' + serie + ' ya existe.',
          'error'
        )
        $('#form-crear-equipo').trigger('reset');
        buscar_datos();
      }
    });
    e.preventDefault();
  });
  // FIN FUNCION

  // FORMULARIO PARA EDITAR EL EQUIPO EN LA BASE DE DATOS
  $('#form-editar-equipo').submit(e => {
    let id_editado = $('#id_equipo').val();
    let nombre = $('#nombre_eq').val();
    let n_activo = $('#activo_eq').val();
    let marca = $('#marca_eq').val();
    let modelo = $('#modelo_eq').val();
    let serie = $('#serie_eq').val();
    let pro_terc = $('#prop_tercero_eq').val();
    let estado = $('#estado_eq').val();
    let garantia = $('#garantia_eq').val();

    funcion = 'editar';
    $.post('../../Controllers/control_equipo.php', { id_editado, nombre, n_activo, marca, modelo, serie, pro_terc, estado, garantia, funcion }, (response) => {
      if (response == 'update') {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Los datos del equipo ' + nombre + ' fueron actualizados correctamente.',
          showConfirmButton: false,
          timer: 1500
        })
        $('#form-editar-equipo').trigger('reset');
        buscar_datos();
      }
    });
    e.preventDefault();
  });
  // FIN FUNCION

  // FUNCIÓN BUSCAR Y EXPORTAR LOS DATOS DEL EQUIPO
  function buscar_datos(consulta) {
    funcion = 'buscar_datos_equipo';
    $.post('../../Controllers/control_equipo.php', { consulta, funcion }, (response) => {
      const equipos = JSON.parse(response);
      let template = '';
      equipos.forEach(equipo => {
        template += `
            <tr id_equipo="${equipo.id_equipo}" nombre="${equipo.nombre}" no_activo="${equipo.no_activo}" marca="${equipo.marca}"
              modelo="${equipo.modelo}" serie="${equipo.serie}" pro_terc="${equipo.propio_tercero}" estado="${equipo.estado}"
              garantia="${equipo.garantia}">
              <td>${equipo.no_activo}</td>
              <td>${equipo.nombre}</td>
              <td>${equipo.marca}</td>
              <td>${equipo.modelo}</td>
              <td>${equipo.serie}</td>
              <td>${equipo.propio_tercero}</td>
              <td>${equipo.estado}</td>
              <td>${equipo.garantia}</td>
              <div class="text-right">`;
                if (equipo.estatus == 'STOCK') {
                  template += `
                    <td><h1 class="badge badge-info">${equipo.estatus}</h1></td>
                    <td>
                      <button class="editar btn btn-primary" title="Editar los datos del equipo" type="button" data-toggle="modal" data-target="#editar_equipo">
                        <i class="fas fa-pencil-alt"></i>
                      </button>
                      <a class="btn btn-warning" href="../../Views/Admin/Inventario_Equipos.php?id=${equipo.id_equipo}&equipo=${equipo.nombre}&serie=${equipo.serie}" title="Agregar el equipo a un contrato de arriendo y/o matto" >
                        <i class="fas fa-handshake"></i>
                      </a>
                      <button class="eliminar_eq btn btn-danger" title="Borrar los datos del equipo">
                        <i class="fas fa-trash-alt"></i>
                      </button>
                    </td>
                  `;
                } else {
                  template += `
                    <td><h1 class="badge badge-danger">${equipo.estatus}</h1></td>
                    <td>
                      <a class="btn btn-primary" href="../../Views/Admin/Inventario_Equipos.php" title="Click para ir al modulo de los equipos en contrato">
                        <i class="fas fa-clipboard-list"></i>
                      </a>
                    </td>
                  `;
                }
                template += `
              </div>
            </tr>
          `;
      })
      $('#datos_equipos').html(template);
    });
  }
  // FIN FUNCION

  // BOTON PARA FILTRAR POR NRO DE INVENTARIO EN LA TABLA DE EQUIPOS
  $(document).on('keyup', '#buscar_equipos', function () {
    let valor = $(this).val();
    if (valor != "") {
      buscar_datos(valor);
    }
    else {
      buscar_datos();
    }
  });
  // FIN DEL FILTRO

  // BOTON PARA CAPTURAR LOS DATOS DEL EQUIPO Y EDITAR
  $(document).on('click', '.editar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id_editado = $(elemento).attr('id_equipo');
    const nombre = $(elemento).attr('nombre');
    const n_activo = $(elemento).attr('no_activo');
    const marca = $(elemento).attr('marca');
    const modelo = $(elemento).attr('modelo');
    const serial = $(elemento).attr('serie');
    const pro_terc = $(elemento).attr('pro_terc');
    const estado = $(elemento).attr('estado');
    const garantia = $(elemento).attr('garantia');
    $('#id_equipo').val(id_editado);
    $('#nombre_eq').val(nombre);
    $('#activo_eq').val(n_activo);
    $('#marca_eq').val(marca);
    $('#modelo_eq').val(modelo);
    $('#serie_eq').val(serial);
    $('#prop_tercero_eq').val(pro_terc);
    $('#estado_eq').val(estado);
    $('#garantia_eq').val(garantia);
  });
  // FIN BOTON

  // BOTON PARA AGREGAR EL EQUIPO A UN CONTRATO DE ARRIENDO O MATTO
  /*$(document).on('click', '.arrendar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_equipo');
    const nombre = $(elemento).attr('nombreeq');
    const pro_terc = $(elemento).attr('pro_terceq');
    //$('#inventario').val(id + ' - ' + nombre);

    funcion = 'arrendar';
    $.post('../../Controllers/control_equipo.php', { id, funcion }, (response) => {
      if (response == 'arrendado') {
        //$('#form-crear-inventario').trigger('reset');
        buscar_datos();
      }
    });

  });*/
  // FIN BOTON

  // FUNCION PARA AGREGAR EL EQUIPO A CONTRATO DE ARRIENDO
  /*function arrendar(id) {
    funcion = 'arrendar';
    $.post('../../Controllers/control_equipo.php', { id, funcion }, (response) => {
      if (response == 'arrendado') {
        //$('#form-crear-inventario').trigger('reset');
        buscar_datos();
      }
    });
  }*/
  // FIN FUNCION

  // FUNCION PARA AGREGAR EL EQUIPO A CONTRATO DE MATTO
  /*function contrato_matto(id) {
    funcion = 'contrato_matto';
    $.post('../../Controllers/control_equipo.php', { id, funcion }, (response) => {
      if (response == 'contrato') {
        //$('#form-crear-inventario').trigger('reset');
        //buscar_datos();
      }
    });
  }*/
  // FIN FUNCION

  /*function no_arrendar(id) {
    funcion = 'no_arrendar';
    $.post('../../Controllers/control_equipo.php', { id, funcion }, (response) => {
      if (response == 'stock') {

        //$('#form-crear-inventario').trigger('reset');
        //buscar_datos();
      }
    });
  }*/

  $(document).on('click', '.no_arrendar', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_equipo');
    const nombre = $(elemento).attr('nombre');

    Swal.fire({
      title: '¿Desea retornar el equipo ' + nombre + ' al stock?',
      text: "El equipo cambiara el estado de contrato de arriendo y/o de matto a stock!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        funcion = "no_arrendar";
        $.post('../../Controllers/control_equipo.php', { id, funcion }, (response) => {
          if (response == 'stock') {
            Swal.fire(
              '¡Equipo en Stock!',
              'El equipo ' + nombre + ' queda en stock.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '`¡No fue devuelto al stock!',
              'El equipo ' + nombre + ' no fue posible devolverlo al stock.',
              'error'
            )
          }
        });
      }
    })
  });

  // BOTON PARA BORRAR LOS DATOS DEL EQUIPO EN LA BASE DE DATOS
  $(document).on('click', '.eliminar_eq', (e) => {
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_equipo');
    const nombre_equipo = $(elemento).attr('nombre');

    Swal.fire({
      title: '¿Desea borrar el equipo ' + nombre_equipo + '?',
      text: "¡Los datos del equipo seran borrados de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        funcion = "eliminar_eq";
        $.post('../../Controllers/control_equipo.php', { id, nombre_equipo, funcion }, (response) => {
          if (response == 'delete') {
            Swal.fire(
              '¡Borrado!',
              'Los datos del equipo ' + nombre_equipo + ' fueron borrados.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              '¡No fue borrado!',
              'Los datos del equipo ' + nombre_equipo + ' no fueron borrados.',
              'error'
            )
          }
        });
      }
    })
  });
  // FIN BOTON

  // BOTON PARA LIMPIAR EL FORMULARIO CREAR EQUIPO
  $(document).on('click', '#btn_limpiar', (e) => {
    $('#form-crear-equipo').trigger('reset');
    buscar_datos();
  });
  // FIN BOTON

})