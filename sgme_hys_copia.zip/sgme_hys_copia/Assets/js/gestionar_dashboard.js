$(document).ready(function () {
  var funcion = ''; /** Declarar e iniciar la variable funcion */
  buscar_datos_cronograma(); /** Inicializar la función buscar datos del cronograma */
  buscar_datos_solicitud(); /** Inicializar la función buscar datos de la solicitud */
  verificar_session(); /** Inicializar la función verificar sesión */
  loader(); /** Inicializar la función cargar datos desde el servidor */

  /**
   * FUNCIÓN ASINCRONICA LA CUAL VERIFICA LA SESIÓN.
   * if(data.ok) = Realiza la validación para que ningun usuario que no se encuentre en la sesión pueda ingresar a la vista del dashboard.
   */
  async function verificar_session() {
    let funcion = "verificar_session";
    let data = await fetch('/sgme_hys/Controllers/control_usuario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'funcion=' + funcion
    })
    if (data.ok) {
      let response = await data.text();
      try {
        let respuesta = JSON.parse(response);
        if (respuesta.length != 0) {
          close_loader();
        } else {
          location.href = "/sgme_hys/";
        }
      } catch (error) {
        console.error(error);
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Error',
          text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
        })
      }
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: data.statusText,
        text: 'No puede inciar sesión, póngase en contacto con el administrador del sistema. Còdigo: ' + data.status,
      })
    }
  }

  /**
   * FUNCIÓN PARA REFLEJAR LA PANTALLA DE CARGA MIENTRAS TRAE LOS DATOS DEL SERVIDOR.
   * @param {string} msg = Para notificar si los datos estan cargando.
   */ 
  function loader(msg) {
    if (msg == '' || msg == null) {
      msg = "Cargando datos...........";
    }
    Swal.fire({
      position: 'center',
      html: '<i class="fas fa-2x fa-sync-alt fa-spin"></i>',
      title: msg,
      showConfirmButton: false,
      timer: 1500
    })
  }

  /**
   * FUNCIÓN PARA CERRA LA PANTALLA DE CARGA CUANDO TRAE LOS DATOS DEL SERVIDOR.
   * @param {string} msg = Mensaje para notificar si los datos estan cargando.
   * @param {string} tipo = Icono que se muestra al momento de cerrar la pantalla de carga.
   */
  function close_loader(msg, tipo) {
    if (msg == '' || msg == null) {
      Swal.close();
    } else {
      Swal.fire({
        position: 'center',
        icon: tipo,
        title: msg,
        showConfimButton: false,
      })
    }
  }

  /**
   * FUNCIÓN PARA BUSCAR LOS MANTENIMIENTOS AGENDADOS EN EL CRONOGRAMA QUE SE ENCUENTRAN PENDIENTES Y REALIZAR EL REPORTE.
   * @param {string} consulta = Este parametro trae toda la información de los mantenimientos pendientes.
   */
  function buscar_datos_cronograma(consulta) {
    funcion = 'buscar_datos_pendiente';
    $.post('../../Controllers/control_cronograma.php', { consulta, funcion }, (response) => {
      const eventos = JSON.parse(response);
      let template = '';
      eventos.forEach(evento => {
        template += `
          <tr id_cronograma="${evento.id_cronograma}" id_inventario="${evento.id_inventario}">
            <td>${evento.id_cronograma}</td>
            <td>${evento.nombre_eq}</td>
            <td>${evento.serie_eq}</td>
            <td>${evento.titulo}</td>
            <td>${evento.f_inicio}</td>
            <td>${evento.f_final}</td>
            <td>${evento.sede}</td>
            <td>${evento.descripcion}</td>
            <div class="text-right">`;
        if (evento.estado == 'PENDIENTE') {
          template += `
                  <td><h1 class="badge badge-info">${evento.estado}</h1></td>
                  <td>
                    <a class="estado_proceso btn btn-info" href="../../Views/Admin/Reportes.php?id=${evento.id_inventario}&equipo=${evento.nombre_eq}&marca=${evento.marca_eq}&modelo=${evento.modelo_eq}&serie=${evento.serie_eq}&sede=${evento.sede}&area=${evento.area}&evento=${evento.titulo}" title="Crear Reporte">
                      <i class="fas fa-file-alt"></i>
                    </a>
                    <button class="estado_cancelar btn btn-danger" title="Cancelar el mantenimiento programado">
                      <i class="fas fa-times"></i>
                    </button>
                  </td>
                `;
        }
        template += `
            </div>
          </tr>
        `;
      })
      $('#listado_matto').html(template); /** Proyectar el listado de los mantenimientos programados en estado pendiente en la tabla. */
    });
  }

  /**
   * EVENTO CLICK, EL CUAL CONTIENE LA FUNCIÓN PARA CANCELAR EL EVENTO.
   * @param {string} consulta = Este parametro trae toda la información de los mantenimientos pendientes.
   */
  $(document).on('click', '.estado_cancelar', (e) => {
    funcion = "cancelar_evento";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_cronograma');
    const inventario = $(elemento).attr('id_inventario');

    Swal.fire({
      title: '¿Desea cancelar el mantenimiento programado?',
      text: "Se cancelara el mantenimiento programado, pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_cronograma.php', { id, inventario, funcion }, (response) => {
          if (response == 'cancelado') {
            Swal.fire(
              'Mantenimiento Cancelado!',
              'Se cancelo el mantenimiento programado.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue cancelado!',
              'No fue posible cancelar el mantenimiento programado.',
              'error'
            )
          }
        });
      }
    })
  });

  /**
   * FUNCIÓN PARA BUSCAR LAS SOLICITUDES QUE SE ENCUENTRAN PENDIENTES Y AGENDARLAS EN EL CRONOGRAMA.
   * @param {string} consulta = Este parametro trae toda la información de las solicitudes pendientes.
   */
  function buscar_datos_solicitud(consulta) {
    funcion = 'buscar_datos_solicitud_pend';
    $.post('../../Controllers/control_solicitud.php', { consulta, funcion }, (response) => {
      const solicitudes = JSON.parse(response);
      let template = '';
      solicitudes.forEach(solicitud => {
        template += `
          <tr id_solicitud="${solicitud.id_solicitud}" inventario="${solicitud.id_inventario}" >
            <td>${solicitud.id_solicitud}</td>
            <td>${solicitud.fecha_solicitud}</td>
            <td>${solicitud.nombre_equipo}</td>
            <td>${solicitud.nombre_cliente}</td>
            <td>${solicitud.usuario_cliente}</td>
            <td>${solicitud.tipo_solicitud}</td>
            <td>${solicitud.prioridad}</td>
            <td>${solicitud.motivo}</td>
            <div class="text-right">`;
        if (solicitud.estatus_sol == 'PENDIENTE') {
          template += `
                  <td><h1 class="badge badge-info">${solicitud.estatus_sol}</h1></td>
                  <td>
                    <a class="btn btn-info" href="../Admin/Cronograma.php?id_inv=${solicitud.id_inventario}&equipo=${solicitud.nombre_equipo}&marca=${solicitud.marca_equipo}" title="Agendar solicitud de servicio">
                      <i class="fas fa-calendar-check"></i>
                    </a>
                    <button class="estado_cancelar btn btn-danger" title="Cancelar la solicitud de servicio">
                      <i class="fas fa-times"></i>
                    </button>
                  </td>
                `;
        }
        template += `
            </div>
          </tr>
        `;
      })
      $('#solicitudes').html(template); /** Proyectar el listado de las solicitudes en estado pendiente en la tabla. */
    });
  }

  /**
   * EVENTO CLICK, EL CUAL CONTIENE LA FUNCIÓN CANCELAR LA SOLICITUD.
   * @param {string} consulta = Este parametro trae toda la información de los mantenimientos pendientes.
   */
  $(document).on('click', '.estado_cancelar', (e) => {
    funcion = "cancelar_solicitud";
    const elemento = $(this)[0].activeElement.parentElement.parentElement;
    const id = $(elemento).attr('id_solicitud');
    const inventario = $(elemento).attr('inventario');

    Swal.fire({
      title: '¿Desea cancelar la solicitud de servicio # ' + id + '?',
      text: "¡Se cancelara la solicitud de servicio pero no se borra de la base de datos!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('../../Controllers/control_solicitud.php', { id, inventario, funcion }, (response) => {
          if (response == 'cancelado') {
            Swal.fire(
              'Solicitud Cancelada!',
              'La solicitud de servicio # ' + id + ' fue cancelada.',
              'success'
            )
            buscar_datos();
          }
          else {
            Swal.fire(
              'No fue cancelada!',
              'No fue posible cancelar la solicitud # ' + id + ' de servicio.',
              'error'
            )
          }
        });
      }
    })
  });

  //var calendarEl = document.getElementById('calendar');
  //buscar_datos();
  //datos();
  //capturar_datos();
  //total_usuarios();

  /*var calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',

    locale: 'es',
    navLinks: true,
    editable: true,
    eventLimit: true,
    selectable: true,
    selectHelper: false,

    headerToolbar: {
      left: 'prev,next,today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,listWeek'
    },

    events: '',

    dateClick: function(info) {
      //console.log(info);
      document.getElementById('titulo_evento').textContent = 'Agendar Mantenimientos';
      document.getElementById('fecha_inicio').value = info.dateStr;
      crear_cronograma.show();
    }

  });
  calendar.render();*/

  /*function total_usuarios() {
    funcion = 'total_usuarios';
    $.post('../../Controllers/control_usuario.php', { funcion }, (response) => {
      console.log(response);
      
    });
  }

  function datos() {
    funcion = 'datos';
    $.post('../../Controllers/control_dashboard.php', { funcion }, (response) => {
      console.log(response);
      
    });
  }

  function capturar_datos() {
    funcion = 'capturar_datos';
    $.post('../../Controllers/control_reporte.php', { funcion }, (response) => {
      let id = '';
      let inventario = '';
      let tipo_servicio = '';
      let tipo_asistencia = '';
      let fecha_inicio = '';
      const reporte = JSON.parse(response);
      console.log(response);
      id += `${reporte.id_reporte}`;
      inventario += `${reporte.id_inventario}`;
      tipo_servicio += `${reporte.tipo_servicio}`;
      tipo_asistencia += `${reporte.tipo_asistencia}`;
      fecha_inicio += `${reporte.fecha_inicio}`;
      $('#no_reporte').html(id);
      $('#nombre').html(inventario);
      $('#nombre2').html(tipo_servicio);
      $('#nombre3').html(tipo_asistencia);
      $('#nombre4').html(fecha_inicio);
    })
  }*/

  /**
   * FUNCIÓN LA CUAL NOS DICE CUANTOS USUARIOS ESTAN REGISTRADOS EN LA BASE DE DATOS.
   */
  function total_usuarios() {
    let usuarios;
    let count = 0;
    funcion = 'total_usuarios';
    $.post('../../Controllers/control_equipo.php', { funcion }, (response) => {

    });
  }

})