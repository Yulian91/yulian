function loadImage(url) {
  return new Promise(resolve => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = "blob";
    xhr.onload = function (e) {
      const reader = new FileReader();
      reader.onload = function (event) {
        const res = event.target.result;
        resolve(res);
      }
      const file = this.response;
      reader.readAsDataURL(file);
    }
    xhr.send();
  });
}

window.addEventListener('load', async () => {

  const form = document.querySelector('#form');
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    let check_item_1 = document.querySelector('input[name="check_item_1"]:checked').value;
    /*let check_item_2 = document.querySelector('input[name="check_item_2"]:checked').value;
    let check_item_3 = document.querySelector('input[name="check_item_3"]:checked').value;
    let check_item_4 = document.querySelector('input[name="check_item_4"]:checked').value;
    let check_item_5 = document.querySelector('input[name="check_item_5"]:checked').value;
    let check_item_6 = document.querySelector('input[name="check_item_6"]:checked').value;
    let check_item_7 = document.querySelector('input[name="check_item_7"]:checked').value;
    let check_item_8 = document.querySelector('input[name="check_item_8"]:checked').value;
    let check_item_9 = document.querySelector('input[name="check_item_9"]:checked').value;
    let check_item_10 = document.querySelector('input[name="check_item_10"]:checked').value;
    let check_item_11 = document.querySelector('input[name="check_item_11"]:checked').value;
    let check_item_12 = document.querySelector('input[name="check_item_12"]:checked').value;
    let check_item_13 = document.querySelector('input[name="check_item_13"]:checked').value;
    let check_item_14 = document.querySelector('input[name="check_item_14"]:checked').value;
    let check_item_15 = document.querySelector('input[name="check_item_15"]:checked').value;
    let check_item_16 = document.querySelector('input[name="check_item_16"]:checked').value;
    let check_item_17 = document.querySelector('input[name="check_item_17"]:checked').value;
    let check_item_18 = document.querySelector('input[name="check_item_18"]:checked').value;
    let check_item_19 = document.querySelector('input[name="check_item_19"]:checked').value;
    let check_item_20 = document.querySelector('input[name="check_item_20"]:checked').value;
    let check_item_21 = document.querySelector('input[name="check_item_21"]:checked').value;
    let check_item_22 = document.querySelector('input[name="check_item_22"]:checked').value;
    let check_item_23 = document.querySelector('input[name="check_item_23"]:checked').value;
    let check_item_24 = document.querySelector('input[name="check_item_24"]:checked').value;
    let check_item_25 = document.querySelector('input[name="check_item_25"]:checked').value;
    let check_item_26 = document.querySelector('input[name="check_item_26"]:checked').value;
    let check_item_27 = document.querySelector('input[name="check_item_27"]:checked').value;
    let check_item_28 = document.querySelector('input[name="check_item_28"]:checked').value;
    let check_item_29 = document.querySelector('input[name="check_item_29"]:checked').value;
    let check_item_30 = document.querySelector('input[name="check_item_30"]:checked').value;
    let check_item_31 = document.querySelector('input[name="check_item_31"]:checked').value;
    let check_item_32 = document.querySelector('input[name="check_item_32"]:checked').value;
    let check_item_33 = document.querySelector('input[name="check_item_33"]:checked').value;
    let check_item_34 = document.querySelector('input[name="check_item_34"]:checked').value;
    let check_item_35 = document.querySelector('input[name="check_item_35"]:checked').value;
    let check_item_36 = document.querySelector('input[name="check_item_36"]:checked').value;
    let check_item_37 = document.querySelector('input[name="check_item_37"]:checked').value;
    let check_item_38 = document.querySelector('input[name="check_item_38"]:checked').value;
    let check_item_39 = document.querySelector('input[name="check_item_39"]:checked').value;
    let check_item_40 = document.querySelector('input[name="check_item_40"]:checked').value;
    let check_item_41 = document.querySelector('input[name="check_item_41"]:checked').value;
    let check_item_42 = document.querySelector('input[name="check_item_42"]:checked').value;
    let check_item_43 = document.querySelector('input[name="check_item_43"]:checked').value;
    let check_item_44 = document.querySelector('input[name="check_item_44"]:checked').value;
    let check_item_45 = document.querySelector('input[name="check_item_45"]:checked').value;
    let check_item_46 = document.querySelector('input[name="check_item_46"]:checked').value;
    let check_item_47 = document.querySelector('input[name="check_item_47"]:checked').value;
    let check_item_48 = document.querySelector('input[name="check_item_48"]:checked').value;
    let check_item_49 = document.querySelector('input[name="check_item_49"]:checked').value;
    let check_item_50 = document.querySelector('input[name="check_item_50"]:checked').value;
    let check_item_51 = document.querySelector('input[name="check_item_51"]:checked').value;
    let check_item_52 = document.querySelector('input[name="check_item_52"]:checked').value;
    let check_item_53 = document.querySelector('input[name="check_item_53"]:checked').value;
    let check_item_54 = document.querySelector('input[name="check_item_54"]:checked').value;
    let check_item_55 = document.querySelector('input[name="check_item_55"]:checked').value;
    let check_item_56 = document.querySelector('input[name="check_item_56"]:checked').value;
    let check_item_57 = document.querySelector('input[name="check_item_57"]:checked').value;
    let check_item_58 = document.querySelector('input[name="check_item_58"]:checked').value;
    let check_item_59 = document.querySelector('input[name="check_item_59"]:checked').value;
    let check_item_60 = document.querySelector('input[name="check_item_60"]:checked').value;
    let check_item_61 = document.querySelector('input[name="check_item_61"]:checked').value;
    let check_item_62 = document.querySelector('input[name="check_item_62"]:checked').value;
    let check_item_63 = document.querySelector('input[name="check_item_63"]:checked').value;*/
    /*let check_item_ = document.querySelector('input[name="check_item_19"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_20"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_21"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_22"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_23"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_24"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_25"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_26"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_27"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_28"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_29"]:checked').value;
    let check_item_ = document.querySelector('input[name="check_item_30"]:checked').value;*/



    generatePDF(check_item_1 /*check_item_2, check_item_3, check_item_4, check_item_5, check_item_6, check_item_7, check_item_8, check_item_9, check_item_10, check_item_11, check_item_12, check_item_13, check_item_14, check_item_15, check_item_16,
      check_item_17, check_item_18, check_item_19, check_item_20, check_item_21, check_item_22, check_item_23, check_item_24, check_item_25, check_item_26, check_item_27, check_item_28, check_item_29, check_item_30, check_item_31, check_item_32,
      check_item_33, check_item_34, check_item_35, check_item_36, check_item_37, check_item_38, check_item_39, check_item_40, check_item_41, check_item_42, check_item_43, check_item_44, check_item_45, check_item_46, check_item_47, check_item_48,
      check_item_49, check_item_50, check_item_51, check_item_52, check_item_53, check_item_54, check_item_55, check_item_56, check_item_57, check_item_58, check_item_59, check_item_60, check_item_61, check_item_62, check_item_63*/);
  });

});

async function generatePDF(check_item_1 /*check_item_2, check_item_3, check_item_4, check_item_5, check_item_6, check_item_7, check_item_8, check_item_9, check_item_10, check_item_11, check_item_12, check_item_13, check_item_14, check_item_15, check_item_16,
  check_item_17, check_item_18, check_item_19, check_item_20, check_item_21, check_item_22, check_item_23, check_item_24, check_item_25, check_item_26, check_item_27, check_item_28, check_item_29, check_item_30, check_item_31, check_item_32,
  check_item_33, check_item_34, check_item_35, check_item_36, check_item_37, check_item_38, check_item_39, check_item_40, check_item_41, check_item_42, check_item_43, check_item_44, check_item_45, check_item_46, check_item_47, check_item_48,
  check_item_49, check_item_50, check_item_51, check_item_52, check_item_53, check_item_54, check_item_55, check_item_56, check_item_57, check_item_58, check_item_59, check_item_60, check_item_61, check_item_62, check_item_63*/) {

  const image = await loadImage("../Assets/img/1.RX_portatil.jpg");

  const pdf = new jsPDF('p', 'pt', 'letter');

  pdf.addImage(image, 'PNG', 0, 0, 600, 795);

  // -- SELECCIONAR EL TIPO DE MANTENIMIENTO ---

  //pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_1) === 1) {
    pdf.line(496, 140, 498, 90, 'S');
    pdf.line(508, 135, 490, 150, 'S');
    //pdf.line(600, 227, 490, 135, 'S');
    //pdf.circle(498, 120, 7, 'F');
    //pdf.triangle(498, 150, 500, 150, 505, 130, 'F');
    //pdf.lines([[498,120],[-5,5],[1,1,2,2,3,3],[2,1]], 22,12, [1,1], 'F', false);

  } else if (parseInt(check_item_1) === 2) {
    pdf.line(496, 140, 490, 150, 'S');
    pdf.line(508, 135, 490, 150, 'S');
    //pdf.rect(327, 227, 32, 10, 'FD');

  } else if (parseInt(check_item_1) === 3) {
    pdf.rect(499, 227, 32, 10, 'FD');

  } 
  
  /*pdf.setFillColor(180, 180, 180);
  
  if (parseInt(check_item_2) === 4) {
    pdf.rect(141, 239, 33, 10, 'FD');

  } else if (parseInt(check_item_2) === 5) {
    pdf.rect(327, 239, 32, 10, 'FD');

  } else if (parseInt(check_item_2) === 6) {
    pdf.rect(293, 286, 32, 11, 'FD');

  } 
  
  pdf.setFillColor(180, 180, 180);
  
  if (parseInt(check_item_3) === 7) {
    pdf.rect(327, 286, 32, 11, 'FD');

  } else if (parseInt(check_item_3) === 8) {

  } else if (parseInt(check_item_3) === 9) {
    pdf.rect(361, 286, 31, 11, 'FD');

  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_4) === 10) {
    pdf.rect(293, 300, 32, 11, 'FD');

  } else if (parseInt(check_item_4) === 11) {
    pdf.rect(327, 300, 32, 11, 'FD');

  } else if (parseInt(check_item_4) === 12) {
    pdf.rect(361, 300, 31, 11, 'FD');

  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_5) === 13) {
    pdf.rect(293, 313, 32, 11, 'FD');

  } else if (parseInt(check_item_5) === 14) {
    pdf.rect(327, 313, 32, 11, 'FD');

  } else if (parseInt(check_item_5) === 15) {
    pdf.rect(361, 313, 31, 11, 'FD');

  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_6) === 16) {
    pdf.rect(293, 326, 32, 11, 'FD');

  } else if (parseInt(check_item_6) === 17) {
    pdf.rect(327, 326, 32, 11, 'FD');

  } else if (parseInt(check_item_6) === 18) {
    pdf.rect(361, 326, 31, 11, 'FD');

  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_7) === 19) {
    pdf.rect(293, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_7) === 20) {
    pdf.rect(327, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_7) === 21) {
    pdf.rect(361, 339, 31, 11, 'FD');
  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_8) === 22) {
    pdf.rect(293, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_8) === 23) {
    pdf.rect(327, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_8) === 24) {
    pdf.rect(361, 339, 31, 11, 'FD');
  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_9) === 25) {
    pdf.rect(293, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_9) === 26) {
    pdf.rect(327, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_9) === 27) {
    pdf.rect(361, 339, 31, 11, 'FD');
  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_10) === 28) {
    pdf.rect(293, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_10) === 29) {
    pdf.rect(327, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_10) === 30) {
    pdf.rect(361, 339, 31, 11, 'FD');
  };

  pdf.setFillColor(180, 180, 180);

  if (parseInt(check_item_11) === 31) {
    pdf.rect(293, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_11) === 32) {
    pdf.rect(327, 339, 32, 11, 'FD');

  } else if (parseInt(check_item_11) === 33) {
    pdf.line(361, 339, 31, 11, 'FD');
  };*/

  pdf.save("Protocolo de Matto.pdf");

}