<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; // Esta es la conexión con el archivo header.php //
?>
<title>SGME H&S - Datos Personales</title><!-- Titulo de la pagina modulo gestionar areas -->


<!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL AREA EN LA BASE DE DATOS -->
<div class="modal fade" id="cambio_clave" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- id = Es la identificación del modal crear area -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="card card-info">
        <div class="card-header">
          <h3 class="card-title">Cambio de Contraseña</h3><!-- Titulo del modal crear datos del area -->
          <button data-dismiss="modal" aria-label="Close" class="close"><!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <div class="text-center">
            <img src="/sgme_hys/Assets/Util/img/avatar_1.png" class="profile-user-img img-fluid img-circle">
          </div>
          <br>
          <div class="text-center">
            <b> <?php echo $_SESSION['nombre']; ?> </b><br />
            <b> <?php echo $_SESSION['apellido']; ?> </b>
          </div>
          <br>
          <!-- Formulario para ingresar los datos de la ciudad -->
          <form id="form-clave" class="row"><!-- id = Es el identificador del formulario crear area -->
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-unlock-alt"></i></span>
              </div>
              <input id="clave_anterior" type="password" class="form-control" placeholder="Ingrese la contraseña actual"><!-- Caja de texto para ingresar el nuevo nombre del area -->
              <div class="input-group-append">
                <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword1()"> <span class="fa fa-eye-slash icon"></span> </button>
              </div>
            </div>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
              </div>
              <input id="nueva_clave" type="password" class="form-control" placeholder="Ingrese la nueva contraseña"><!-- Caja de texto para ingresar el nuevo nombre del area -->
            </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del area -->
          <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del area -->
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- CONTENIDO DEL MODULO GESTIONAR AREAS -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Datos Personales</h1><!-- Titulo del Modulo gestionar areas -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Datos personales</li><!-- Este item nos indica que nos encontramos en el modulo gestionar areas -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR AREAS -->
  <section>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-5">
            <div class="card card-info card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img src="/sgme_hys/Assets/Util/img/avatar_1.png" class="profile-user-img img-fluid img-circle">
                </div>
                <input id="id_usuario" type="hidden" value="<?php echo $_SESSION['id'] ?>">
                <h3 id="nombre" class="profile-username text-center"></h3>
                <p id="apellidos" class="profile-username text-center"></p>
                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <i class="fas fa-address-card mr-1">Identificación</i>
                    <a id="identificacion" class="float-right text-dark"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-user mr-1">Tipo Usuario</i>
                    <a id="tipo_usu" class="float-right badge badge-primary"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-at mr-1">E-mail</i>
                    <a id="email" class="float-right text-dark"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-mobile mr-1">Telefono</i>
                    <a id="telefono" class="float-right text-dark"></a>
                  </li>
                  <li class="list-group-item">
                    <i class="fas fa-map-marker-alt mr-1">Dirección</i>
                    <a id="direccion" class="float-right text-dark"></a>
                  </li>
                </ul>
                <div class="row">
                  <div class="col-md-6">
                    <button class="edit btn btn-block bg-gradient-success">Editar datos</button>
                  </div>
                  <div class="col-md-6">
                    <button type="button" class="btn btn-block bg-gradient-warning" data-toggle="modal" data-target="#cambio_clave">Cambiar contraseña</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- FORMULARIO PARA EDITAR LOS DATOS DEL AREA -->
          <div class="col-md-7">
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Editar datos personales</h3>
              </div>
              <div class="card-footer">
                <!-- Formulario para ingresar los datos de la ciudad -->
                <form id="form-usuario" class="form-horizontal"><!-- id = Es el identificador del formulario editar area -->
                  <div class="form-group row">
                    <label for="nombre" class="col-sm-2 col-form-label">Nombre</label>
                    <div class="col-sm-10">
                      <input type="text" id="nombre_usu" class="form-control"><!-- Caja de texto para ingresar el nuevo nombre del area -->
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="apellidos" class="col-sm-2 col-form-label">Apellidos</label>
                    <div class="col-sm-10">
                      <input type="text" id="apellidos_usu" class="form-control"><!-- Caja de texto para ingresar el nuevo nombre del area -->
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="identificacion" class="col-sm-2 col-form-label">Identificación</label>
                    <div class="col-sm-10">
                      <input type="text" id="identificacion_usu" class="form-control"><!-- Caja de texto para ingresar el nuevo nombre del area -->
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="email" class="col-sm-2 col-form-label">Correo</label>
                    <div class="col-sm-10">
                      <input type="text" id="email_usu" class="form-control"><!-- Caja de texto para ingresar el nuevo nombre del area -->
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="contacto" class="col-sm-2 col-form-label">Telefono</label>
                    <div class="col-sm-10">
                      <input type="text" id="contacto_usu" class="form-control"><!-- Caja de texto para ingresar el nuevo nombre del area -->
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="direccion" class="col-sm-2 col-form-label">Dirección</label>
                    <div class="col-sm-10">
                      <input type="text" id="direccion_usu" class="form-control"><!-- Caja de texto para ingresar el nuevo nombre del area -->
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="offset-sm-2 col-sm-10 float-right">
                      <button class="btn btn-block btn-outline-success">Guardar</button><!-- Boton para guardar los datos del area -->
                    </div>
                  </div>
                </form>
                <!-- Fin del formulario -->
              </div>
            </div>
          </div>
          <!-- FIN CODIGO FORMULARIO -->
        </div>
      </div>
    </div>
  </section>
  <!-- /.FIN CONTENIDO DE LA TABLA -->
</div>
<!-- /.FIN CONTENIDO MODULO GESTIONAR AREAS -->
<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php'; // Esta es la conexión con el archivo footer.php //
?>
<script src="/sgme_hys/Assets/js/usuario.js"></script><!--/.Esta es la conexión del archivo areas.php con el archivo gestionar_ciudades.js -->