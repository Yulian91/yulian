<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; // Esta es la conexión con el archivo header.php //
?>

<title>SGME H&S - Dashboard</title><!-- Titulo de la pagina modulo gestionar areas -->

<!-- CONTENIDO DEL MODULO GESTIONAR AREAS -->
<div class="content-wrapper" style="min-height: 568px;">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Dashboard</h1><!-- Titulo del modal crear datos del area -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="/sgme_hys/Views/Admin/Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
            <li class="breadcrumb-item active">Dashboard</li><!-- Este item nos indica que nos encontramos en el modulo gestionar areas -->
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info">
          <div class="inner">
            <h3>02</h3>
            <p>Usuarios Registrados</p>
          </div>
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          <a href="/sgme_hys/Views/Admin/Usuarios.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success">
          <div class="inner">
            <h3>12<sup style="font-size: 20px"></sup></h3>
            <p>Clientes Registrados</p>
          </div>
          <div class="icon">
            <i class="ion ion-stats-bars"></i>
          </div>
          <a href="/sgme_hys/Views/Admin/Clientes.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning">
          <div class="inner">
            <h3>35</h3>
            <p>Inventario Equipos</p>
          </div>
          <div class="icon">
            <i class="ion ion-person-add"></i>
          </div>
          <a href="/sgme_hys/Views/Admin/Equipos.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger">
          <div class="inner">
            <h3>40</h3>
            <p>Reportes Servicio</p>
          </div>
          <div class="icon">
            <i class="ion ion-pie-graph"></i>
          </div>
          <a href="/sgme_hys/Views/Admin/Reportes.php" class="small-box-footer">Mas info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="card card-info">
          <div class="card-header">
            <div class="card-title">Mantenimientos programados pendientes</div><!-- Titulo -->
          </div>
          <div class="card-body p-0 table-responsive">
            <!-- Esta es la tabla de los datos de las areas registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
            <table class="table table-over text-nowrap">
              <thead class="table-info"><!-- Este es la clase de la tabla la cual define el color de la misma -->
                <tr><!-- Estos son los titulos de la tabla -->
                  <th>N.</th>
                  <th>Equipo</th>
                  <th>Serie</th>
                  <th>Actividad</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Final</th>
                  <th>Sede</th>
                  <th>Descripcíon</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody class="table-active" id="listado_matto"><!-- id = Es el identificador de la tabla ciudades -->
              </tbody>
            </table>
            <!-- Fin de la tabla -->
          </div>
          <div class="card-footer"></div>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="card card-info">
          <div class="card-header">
            <div class="card-title">Solicitudes de servicio pendientes</div><!-- Titulo -->
          </div>
          <div class="card-body p-0 table-responsive">
            <!-- Esta es la tabla de los datos de las areas registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
            <table class="table table-over text-nowrap">
              <thead class="table-info"><!-- Este es la clase de la tabla la cual define el color de la misma -->
                <tr><!-- Estos son los titulos de la tabla -->
                  <th># Solicitud</th>
                  <th>Fecha</th>
                  <th>Equipo</th>
                  <th>Cliente / Empresa</th>
                  <th>Solicitado por</th>
                  <th>Tipo Solicitud</th>
                  <th>Prioridad</th>
                  <th>Motivo Servicio</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody class="table-active" id="solicitudes"><!-- id = Es el identificador de la tabla ciudades -->
              </tbody>
            </table>
            <!-- Fin de la tabla -->
          </div>
          <div class="card-footer"></div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
  </section>

</div>

<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php'; // Esta es la conexión con el archivo footer.php //
?>
<script src="/sgme_hys/Assets/js/gestionar_dashboard.js"></script><!--/.Esta es la conexión del archivo areas.php con el archivo gestionar_ciudades.js -->