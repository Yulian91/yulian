<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; // Esta es la conexión con el archivo header.php //
?>
  <title>SGME H&S - Modulo Equipos</title><!-- Titulo de la pagina modulo gestionar areas -->

  <!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL AREA EN LA BASE DE DATOS -->
  <div class="modal fade" id="crear_equipo" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- id = Es la identificación del modal crear area -->
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title">Crear equipo</h3><!-- Titulo del modal crear datos del area -->
            <button data-dismiss="modal" aria-label="Close" class="close"><!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="card-body">
            <!-- Formulario para ingresar los datos de la ciudad -->
            <form id="form-crear-equipo" class="row"><!-- id = Es el identificador del formulario crear area -->
              <div class="col-md-6">
                <label for="nombre_equipo" class="form-label">Nombre equipo</label>
                <input type="text" class="form-control" id="equipo" placeholder="Ingrese el nombre del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="n_activo" class="form-label">No de inventario</label>
                <input type="text" class="form-control" id="n_activo" placeholder="Ingrese el numero de inventario" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="marca" class="form-label">Marca</label>
                <input type="text" class="form-control" id="marca" placeholder="Ingrese la marca del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="modelo" class="form-label">Modelo</label>
                <input type="text" class="form-control" id="modelo" placeholder="Ingrese el modelo del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="serie" class="form-label">Serie</label>
                <input type="text" class="form-control" id="serie" placeholder="Ingrese el serial del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="propio_tercero" class="form-label">Propio / Tercero</label>
                <input type="text" class="form-control" id="pro_terc" placeholder="Ingrese si el equipo es propio o tercero" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="estado" class="form-label">Estado</label>
                <input type="text" class="form-control" id="estado" placeholder="Ingrese el estado del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="garantia" class="form-label">Garantia</label>
                <input type="text" class="form-control" id="garantia" placeholder="Ingrese si esta vigente la garantia" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del area -->
            <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del area -->
          </div>
          </form>
          <!-- Fin del formulario -->
        </div>
      </div>
    </div>
  </div>
  <!-- FIN CODIGO MODAL -->

  <!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL AREA -->
  <div class="modal fade" id="editar_equipo" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- id = Es la identificación del modal crear area -->
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title">Editar equipo</h3><!-- Titulo del modal crear datos del area -->
            <button data-dismiss="modal" aria-label="Close" class="close"><!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="card-body">
            <!-- Formulario para ingresar los datos de la ciudad -->
            <form id="form-editar-equipo" class="row"><!-- id = Es el identificador del formulario editar area -->
              <div class="col-md-6">
                <input type="hidden" id="id_equipo">
                <label for="nombre_equipo" class="form-label">Nombre equipo</label>
                <input type="text" class="form-control" id="nombre_eq" placeholder="Ingrese el nombre del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="n_activo" class="form-label">No de inventario</label>
                <input type="text" class="form-control" id="activo_eq" placeholder="Ingrese el numero de inventario" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="marca" class="form-label">Marca</label>
                <input type="text" class="form-control" id="marca_eq" placeholder="Ingrese la marca del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="modelo" class="form-label">Modelo</label>
                <input type="text" class="form-control" id="modelo_eq" placeholder="Ingrese el modelo del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="serie" class="form-label">Serie</label>
                <input type="text" class="form-control" id="serie_eq" placeholder="Ingrese el serial del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="propio_tercero" class="form-label">Propio / Tercero</label>
                <input type="text" class="form-control" id="prop_tercero_eq" placeholder="Ingrese si el equipo es propio o tercero" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="estado" class="form-label">Estado</label>
                <input type="text" class="form-control" id="estado_eq" placeholder="Ingrese el estado del equipo" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="garantia" class="form-label">Garantia</label>
                <input type="text" class="form-control" id="garantia_eq" placeholder="Ingrese si esta vigente la garantia" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del area -->
            <button type="button" id="btn_limpiar" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del area -->
          </div>
          </form>
          <!-- Fin del formulario -->
        </div>
      </div>
    </div>
  </div>
  <!-- FIN CODIGO MODAL -->

  <!-- CONTENIDO DEL MODULO GESTIONAR AREAS -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Inventario de Equipos</h1><!-- Titulo del Modulo gestionar areas -->
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
              <li class="breadcrumb-item active">Inventario de equipos</li><!-- Este item nos indica que nos encontramos en el modulo gestionar areas -->
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR AREAS -->
    <section>
      <div class="container-fluid">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title">Buscar equipos</h3><!-- Titulo del buscador -->
            <div class="input-group">
              <input type="text" id="buscar_equipos" class="form-control float-left" placeholder="Ingresar el numero de inventario del equipo biomedico"><!-- Este campo es para buscar el nombre de una area especifica -->
              <div class="input-group-append">
                <button class="btn btn-default"><i class="fas fa-search"></i></button>
              </div>
              <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_equipo">Crear equipo</button><!-- Este boton es para crear una nueva area. Al dar clic se abrira el modal crear area -->
            </div>
          </div>
          <div class="card-body p-0 table-responsive">
            <!-- Esta es la tabla de los datos de las areas registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
            <table class="table table-over text-nowrap">
              <thead class="table-info"><!-- Este es la clase de la tabla la cual define el color de la misma -->
                <tr><!-- Estos son los titulos de la tabla -->
                  <th># Inv.</th>
                  <th>Equipo</th>
                  <th>Marca</th>
                  <th>Modelo</th>
                  <th>Serie</th>
                  <th>Pro/Ter</th>
                  <th>Estado Eq</th>
                  <th>Garantia</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody class="table-active" id="datos_equipos"><!-- id = Es el identificador de la tabla ciudades -->
              </tbody>
            </table>
            <!-- Fin de la tabla -->
          </div>
          <div class="card-footer">
          </div>
        </div>
      </div>
    </section>
    <!-- /.FIN CONTENIDO DE LA TABLA -->
  </div>
  <!-- /.FIN CONTENIDO MODULO GESTIONAR AREAS -->
<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php'; // Esta es la conexión con el archivo footer.php //
?>
<script src="/sgme_hys/Assets/js/gestionar_equipos.js"></script><!--/.Esta es la conexión del archivo areas.php con el archivo gestionar_ciudades.js -->