<?php
session_start();
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/header.php'; // Esta es la conexión con el archivo header.php //
?>
  <title>SGME H&S - Modulo Clientes</title><!-- Titulo de la pagina modulo gestionar areas -->

  <!-- MODAL CON EL FORMULARIO PARA CREAR LOS DATOS DEL AREA EN LA BASE DE DATOS -->
  <div class="modal fade" id="crear_cliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- id = Es la identificación del modal crear area -->
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title">Crear cliente</h3><!-- Titulo del modal crear datos del area -->
            <button data-dismiss="modal" aria-label="Close" class="close"><!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="card-body">
            <!-- Formulario para ingresar los datos de la ciudad -->
            <form id="form-crear-cliente" class="row"><!-- id = Es el identificador del formulario crear area -->
              <div class="col-md-6">
                <label for="nombre_cliente" class="form-label">Cliente / Empresa</label>
                <input type="text" class="form-control" id="nombre" placeholder="Ingrese el nombre del cliente" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="nit_cliente" class="form-label">Nit / Id</label>
                <input type="text" class="form-control" id="nit" placeholder="Ingrese el nit" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="telefono_cliente" class="form-label">Telefono cliente</label>
                <input type="text" class="form-control" id="telefono" placeholder="Ingrese el telefono del contacto" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="tipo_contrato" class="form-label">Tipo de contrato</label>
                <input type="text" class="form-control" id="tipo_contrato" placeholder="Ingrese el tipo de contrato" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="num_contrato" class="form-label">No. de contrato</label>
                <input type="text" class="form-control" id="num_contrato" placeholder="Ingrese el Nº de contrato" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="direccion_cliente" class="form-label">Dirección / Ciudad</label>
                <input type="text" class="form-control" id="direccion" placeholder="Ingrese la dirección de residencia" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="usuario" class="form-label">Nombre del contacto</label>
                <input type="text" class="form-control" id="name_contacto" placeholder="Ingrese el nombre del contacto" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="email_cliente" class="form-label">Correo electronico</label>
                <input type="text" class="form-control" id="email" placeholder="Ingrese el correo electronico" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del area -->
            <button type="button" id="btn_limpiar_1" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del area -->
          </div>
          </form>
          <!-- Fin del formulario -->
        </div>
      </div>
    </div>
  </div>
  <!-- FIN CODIGO MODAL -->

  <!-- MODAL CON EL FORMULARIO PARA EDITAR LOS DATOS DEL AREA -->
  <div class="modal fade" id="editar_cliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- id = Es la identificación del modal crear area -->
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title">Editar cliente</h3><!-- Titulo del modal crear datos del area -->
            <button data-dismiss="modal" aria-label="Close" class="close"><!-- Este es el icono X que se visualiza en la parte superior del modal y sirve para cerrar el modal -->
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="card-body">
            <!-- Formulario para ingresar los datos de la ciudad -->
            <form id="form-editar-cliente" class="row"><!-- id = Es el identificador del formulario editar area -->
              <div class="col-md-6">
                <input type="hidden" id="id_cliente">
                <label for="nombre_cliente" class="form-label">Cliente / Empresa</label>
                <input type="text" class="form-control" id="nombre_cli" placeholder="Ingrese el nombre del cliente" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="nit_cliente" class="form-label">Nit / Id</label>
                <input type="text" class="form-control" id="nit_cli" placeholder="Ingrese el nit" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="telefono_cliente" class="form-label">Telefono cliente</label>
                <input type="text" class="form-control" id="telefono_cli" placeholder="Ingrese el telefono del contacto" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="tipo_contrato" class="form-label">Tipo de contrato</label>
                <input type="text" class="form-control" id="tipo_contrato_cli" placeholder="Ingrese el tipo de contrato" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="num_contrato" class="form-label">No. de contrato</label>
                <input type="text" class="form-control" id="no_contrato_cli" placeholder="Ingrese el Nº de contrato" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="direccion_cliente" class="form-label">Dirección / Ciudad</label>
                <input type="text" class="form-control" id="direccion_cli" placeholder="Ingrese la dirección de residencia" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="usuario" class="form-label">Nombre del contacto</label>
                <input type="text" class="form-control" id="name_contacto_cli" placeholder="Ingrese el nombre del contacto" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
              <div class="col-md-6">
                <label for="email_cliente" class="form-label">Correo electronico</label>
                <input type="text" class="form-control" id="email_cli" placeholder="Ingrese el correo electronico" required><!-- Caja de texto para ingresar el nuevo nombre del area -->
              </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary float-right m-1">Guardar</button><!-- Boton para guardar los datos del area -->
            <button type="button" id="btn_limpiar_2" data-dismiss="modal" class="btn btn-danger float-right m-1">Cancelar</button><!-- Boton para cancelar el ingreso de los datos del area -->
          </div>
          </form>
          <!-- Fin del formulario -->
        </div>
      </div>
    </div>
  </div>
  <!-- FIN CODIGO MODAL -->

  <!-- CONTENIDO DEL MODULO GESTIONAR AREAS -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Gestionar Clientes</h1><!-- Titulo del Modulo gestionar areas -->
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="Dashboard.php">Inicio</a></li><!-- Al dar clic en este item nos direccionara al dashboard -->
              <li class="breadcrumb-item active">Gestionar clientes</li><!-- Este item nos indica que nos encontramos en el modulo gestionar areas -->
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- CONTENIDO DE LA TABLA DEL MODULO GESTIOINAR AREAS -->
    <section>
      <div class="container-fluid">
        <div class="card card-info">
          <div class="card-header">
            <h3 class="card-title">Buscar clientes</h3><!-- Titulo del buscador -->
            <div class="input-group">
              <input type="text" id="buscar_cliente" class="form-control float-left" placeholder="Ingresar el nombre y/o razon social del cliente"><!-- Este campo es para buscar el nombre de una area especifica -->
              <div class="input-group-append">
                <button class="btn btn-default"><i class="fas fa-search"></i></button>
              </div>
              <button type="button" class="btn bg-gradient-success ml-4" data-toggle="modal" data-target="#crear_cliente">Crear cliente</button><!-- Este boton es para crear una nueva area. Al dar clic se abrira el modal crear area -->
            </div>
          </div>
          <div class="card-body p-0 table-responsive">
            <!-- Esta es la tabla de los datos de las areas registradas en la base de datos. En esta tabla tambien estan las opciones de editar, borrar, inactivar -->
            <table class="table table-over text-nowrap">
              <thead class="table-info"><!-- Este es la clase de la tabla la cual define el color de la misma -->
                <tr><!-- Cabecera que contiene los titulos de la tabla -->
                  <th>Cliente / Empresa</th>
                  <th>Nit / Id</th>
                  <th>Telefono</th>
                  <th>Tipo Contrato</th>
                  <th># Contrato</th>
                  <th>Dirección / Ciudad</th>
                  <th>@Email</th>
                  <th>Nombre Contacto</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody class="table-active" id="clientes"><!-- id = Es el identificador de la tabla ciudades -->
              </tbody>
            </table>
            <!-- Fin de la tabla -->
          </div>
          <div class="card-footer">
          </div>
        </div>
      </div>
      <!-- /.FIN CONTENIDO DE LA TABLA -->
    </section>
  </div>
  <!-- /.FIN CONTENIDO MODULO GESTIONAR AREAS -->
<?php
include_once $_SERVER["DOCUMENT_ROOT"] . '/sgme_hys/Views/layouts/footer.php'; // Esta es la conexión con el archivo footer.php //
?>
<script src="/sgme_hys/Assets/js/gestionar_clientes.js"></script><!--/.Esta es la conexión del archivo areas.php con el archivo gestionar_ciudades.js -->