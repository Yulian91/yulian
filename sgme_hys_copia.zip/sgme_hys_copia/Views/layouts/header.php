<!-- CONTENIDO DE LA PAGINA HTML -->
<!DOCTYPE html>
<html lang="es" style="height: auto;" class="">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="/sgme_hys/Assets/Util/img/tools_web.png">

  <!-- Estas son las rutas de los archivos estilos.css -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&amp;display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="/sgme_hys/Assets/Util/css/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/sgme_hys/Assets/Util/css/adminlte.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="/sgme_hys/Assets/Util/css/datatables.min.css">
  <!-- sweetalert2 -->
  <link rel="stylesheet" href="/sgme_hys/Assets/css/sweetalert2.css">
  <!-- select2 -->
  <link rel="stylesheet" href="/sgme_hys/Assets/css/select2.css">
  <!-- Full Calendar  -->
  <link rel="stylesheet" href="/sgme_hys/Assets/css/main.min.css">

</head>

<!-- CONTENIDO DEL MENU PRINCIPAL LATERAL Y BARRA DE NAVEGACIÓN SUPERIOR -->
<body class="sidebar-mini layout-navbar-fixed layout-fixed layout-footer-fixed accent-info" style="height: auto;"><!-- Diseño de la barra de navegación -->
  <div class="wrapper">
    <!-- Contenido barra de navegación superior -->
    <nav class="main-header navbar navbar-expand navbar-light bg-info navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <!-- Icono de notificaciones -->
        <li class="nav-item dropdown">
          <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="far fa-bell"></i>
            <span class="badge badge-warning navbar-badge">15</span>
          </a>
          <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <span class="dropdown-item dropdown-header">15 Notifications</span>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
              <i class="fas fa-envelope mr-2"></i> 4 new messages
              <span class="float-right text-muted text-sm">3 mins</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
              <i class="fas fa-users mr-2"></i> 8 friend requests
              <span class="float-right text-muted text-sm">12 hours</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
              <i class="fas fa-file mr-2"></i> 3 new reports
              <span class="float-right text-muted text-sm">2 days</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
          </div>
        </li>
        <!-- Fin del icono de notificaciones -->

        <!-- Icono del perfil y cerrar sesión-->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
            <img src="/sgme_hys/Assets/Util/img/avatar_1.png" width="30" height="30" class="img-fluid img-circle">
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="/sgme_hys/Views/Admin/Datos_Personales.php"><i class="fas fa-user-cog"></i>Mi perfil</a></li>
            <li><a class="dropdown-item" href="/sgme_hys/Controllers/login_salir.php"><i class="fas fa-sign-out-alt"></i>Salir</a></li>
          </ul>
        </li>
        <!-- Fin icono del perfil y cerrar sesión -->
      </ul>
    </nav>
    <!-- Fin del contenido de la barra de navegación superior -->

    <!-- CONTENIDO DEL MENU PRINCIPAL LATERAL -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <a href="/sgme_hys/Views/Admin/Dashboard.php" class="brand-link"><!-- Ruta para acceder al dashboard del software -->
        <img src="/sgme_hys/Assets/Util/img/tools_web.png" alt="Logo H&S" class="brand-image img-circle elevation-3" style="opacity: .8"><!-- Imagen predeterminada del software -->
        <span class="brand-text font-weight-light">SGME H&S</span><!-- Nombre del software -->
      </a>
      <div class="sidebar" style="overflow-y: auto;">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="/sgme_hys/Assets/Util/img/avatar_1.png" class="img-circle elevation-2" alt="User Image"><!-- Imagen del avatar del usuario que se encuentra en sesión -->
          </div>
          <div class="info">
            <a href="/sgme_hys/Views/Admin/Datos_Personales.php" class="d-block"><!-- Ruta para acceder a los datos personales del usuario que se encuentra en sesión -->
              <b><?php echo $_SESSION['nombre'] ?></b><br/><!-- Nombre(s) del usuario que se encuentra en sesión -->
              <b><?php echo $_SESSION['apellido'] ?></b><!-- Apellido(s) del usuario que se encuentra en sesión -->
            </a>
          </div>
        </div>

        <!-- Modulos del menu principal -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-header">MENU PRINCIPAL</li>
            <li class="nav-item">
              <!-- Modulo de usuarios -->
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-users"></i>
                <p>
                  Usuarios
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Datos_Personales.php" class="nav-link">
                    <i class="nav-icon fas fa-user-cog"></i>
                    <p>Datos Personales</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Usuarios.php" class="nav-link">
                    <i class="nav-icon fas fa-users-cog"></i>
                    <p>Gestión de Usuarios</p>
                  </a>
                </li>
              </ul>
            </li>
            <!--/.Fin modulo solicitudes de usuarios -->
            <!-- Modulo de clientes -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-city"></i>
                <p>
                  Clientes
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Clientes.php" class="nav-link">
                    <i class="nav-icon fas fa-building"></i>
                    <p>Gestión de Clientes</p>
                  </a>
                </li>
              </ul>
            </li>
            <!--/.Fin modulo de clientes -->
            <!-- Modulo de ubicación -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-map-marked-alt"></i>
                <p>
                  Ubicación
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Paises.php" class="nav-link">
                    <i class="nav-icon fas fa-globe-americas"></i>
                    <p>Paises</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Ciudades.php" class="nav-link">
                    <i class="nav-icon fas fa-city"></i>
                    <p>Ciudades</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Sedes.php" class="nav-link">
                    <i class="nav-icon fas fa-clinic-medical"></i>
                    <p>Sedes</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Areas.php" class="nav-link">
                    <i class="nav-icon fas fa-x-ray"></i>
                    <p>Areas</p>
                  </a>
                </li>
              </ul>
            </li>
            <!--/.Fin modulo de ubicación -->
            <!-- Modulo de equipos -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-database"></i>
                <p>
                  Equipos
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Equipos.php" class="nav-link">
                    <i class="nav-icon fas fa-stethoscope"></i>
                    <p>Inventario Equipos</p>
                  </a>
                </li>
              </ul>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Inventario_Equipos.php" class="nav-link">
                    <i class="nav-icon fas fa-list-alt"></i>
                    <p>Equipos en contrato </p>
                  </a>
                </li>
              </ul>
            </li>
            <!--/.Fin modulo de equipos -->
            <!-- Modulo plan de mantenimiento -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-calendar-alt"></i>
                <p>
                  Plan de Mantenimiento
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Cronograma.php" class="nav-link">
                    <i class="nav-icon fas fa-calendar-alt"></i>
                    <p>Cronograma</p>
                  </a>
                </li>
              </ul>
            </li>
            <!--/.Fin modulo plan de mantenimiento -->
            <!-- Modulo solicitudes de servicio -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-clipboard"></i>
                <p>
                  Solicitudes de Servicio
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Solicitudes.php" class="nav-link">
                    <i class="nav-icon fas fa-clipboard-check"></i>
                    <p>Gestión de Solicitudes</p>
                  </a>
                </li>
              </ul>
            </li>
            <!--/.Fin modulo solicitudes de servicio -->
            <!-- Modulo reportes de servicio -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-clipboard-list"></i>
                <p>
                  Reportes de Servicio
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="/sgme_hys/Views/Admin/Reportes.php" class="nav-link">
                    <i class="nav-icon fas fa-clipboard-check"></i>
                    <p>Gestión de Reportes</p>
                  </a>
                </li>
              </ul>
            </li>
            <!--/.Fin modulo reportes de servicio -->
          </ul>
        </nav>
        <!--/.Fin modulos del menu principal -->
      </div>
    </aside>
    <!--/.FIN CONTENIDO DEL MENU PRINCIPAL LATERAL -->