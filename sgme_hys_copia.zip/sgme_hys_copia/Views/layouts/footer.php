<!-- CONTENIDO DEL PIE DE PAGINA -->
<footer class="main-footer text-sm">
  <div class="float-right d-none d-sm-block">
    <b>Version</b> 2.0
  </div>
  <strong>&copy; 2022 - 2023 <a href="http://hmtecbiomedica.com/">SGME H&S</a> | </strong> Todos los derechos reservados.
</footer>
<!--/.FIN DEL CONTENIDO PIE DE PAGINA -->

</div>

<!-- Estas son las rutas de los archivos JaveScript -->
<!-- jQuery -->
<script src="/sgme_hys/Assets/Util/js/jquery.min.js"></script>
<!-- Bootstrap 4.6 -->
<script src="/sgme_hys/Assets/Util/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/sgme_hys/Assets/Util/js/adminlte.min.js"></script>
<!-- DataTables -->
<script src="/sgme_hys/Assets/Util/js/datatables.min.js"></script>
<!-- sweetalert2 -->
<script src="/sgme_hys/Assets/js/sweetalert2.js"></script>
<!-- select2 -->
<script src="/sgme_hys/Assets/js/select2.js"></script>
<!-- Full Calendar  -->
<script src="/sgme_hys/Assets/js/moment.min.js"></script>
<script src="/sgme_hys/Assets/js/main.js"></script>
<script src="/sgme_hys/Assets/js/es.js"></script>

</body>
<!--/.CONTENIDO DEL MENU PRINCIPAL LATERAL Y BARRA DE NAVEGACIÓN SUPERIOR -->

</html>
<!--/.FIN CONTENIDO DE LA PAGINA HTML -->