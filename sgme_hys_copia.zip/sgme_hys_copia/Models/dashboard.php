<?php
// CLASE PARA REALIZAR LA CONEXION PDO

include_once 'conexion.php';
class Dashboard{
    var $objetos;
    public function __construct(){
        $db = new Conexion();
        $this->acceso = $db->pdo;
    }

    function datos($table){
        $sql = "SELECT COUNT(*) AS total FROM $table";
        $query = $this->acceso->prepare($sql);
        $query->execute();
        $this->objetos = $query->fetchall();
        return $this->objetos;
    }
}

// FIN DE LA CLASE
?>