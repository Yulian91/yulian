<?php
// CLASE PARA REALIZAR LA CONEXION PDO

include_once '../Config/conexion.php';
class Cliente
{
  var $objetos;
  public function __construct()
  {
    $db = new Conexion();
    $this->acceso = $db->pdo;
  }

  // FUNCION PARA CREAR CLIENTES EN LA BASE DE DATOS
  function Crear_Cliente($nombre, $nit, $telefono, $tipo_contrato, $num_contrato, $direccion, $contacto, $email)
  {
    $sql = "SELECT id_cliente FROM cliente WHERE nit_cliente=:nit";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':nit' => $nit));
    $this->objetos = $query->fetchall();
    if (!empty($this->objetos)) {
      echo 'noadd';
    } else {
      $sql = "INSERT INTO cliente(nombre_rz,nit_cliente,telefono_cliente,tipo_contrato,num_contrato,direccion_ciudad,nombre_contacto,email_cliente) 
            VALUES (:nombre,:nit,:telefono,:tipo_contrato,:num_contrato,:direccion,:contacto,:email)";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(
        ':nombre' => $nombre, ':nit' => $nit, ':telefono' => $telefono, ':tipo_contrato' => $tipo_contrato, ':num_contrato' => $num_contrato,
        ':direccion' => $direccion, ':contacto' => $contacto, ':email' => $email
      ));
      echo 'add';
    }
  }
  // FIN

  // FUNCION PARA EDITAR LOS CLIENTES REGISTRADOS EN LA BASE DE DATOS
  function editar_cliente($id_cliente, $nombre, $nit, $telefono, $tipo_contrato, $num_contrato, $direccion, $contacto, $email)
  {
    $sql = "UPDATE cliente SET nombre_rz=:nombre, nit_cliente=:nit, telefono_cliente=:telefono, tipo_contrato=:tipo_contrato, num_contrato=:num_contrato,
        direccion_ciudad=:direccion, nombre_contacto=:contacto, email_cliente=:email WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id_cliente, ':nombre' => $nombre, ':nit' => $nit, ':telefono' => $telefono, ':tipo_contrato' => $tipo_contrato, 
    ':num_contrato' => $num_contrato, ':direccion' => $direccion, ':contacto' => $contacto, ':email' => $email));
    echo 'update';
  }
  // FIN

  // FUNCION PARA BUSCAR LOS CLIENTES REGISTRADOS EN LA BASE DE DATOS
  function buscador_clientes()
  {
    if (!empty($_POST['consulta'])) {
      $consulta = $_POST['consulta'];
      $sql = "SELECT id_cliente, fecha_reg, nombre_rz, nit_cliente, telefono_cliente, tipo_contrato, num_contrato, direccion_ciudad, email_cliente, nombre_contacto, estatus_cliente
            FROM cliente WHERE id_cliente LIKE :consulta";
      $query = $this->acceso->prepare($sql);
      $query->execute(array(':consulta' => "%$consulta%"));
      $this->objetos = $query->fetchall();
      return $this->objetos;
    } else {
      $sql = "SELECT id_cliente, fecha_reg, nombre_rz, nit_cliente, telefono_cliente, tipo_contrato, num_contrato, direccion_ciudad, email_cliente, nombre_contacto, estatus_cliente
            FROM cliente WHERE nombre_rz NOT LIKE '' ORDER BY id_cliente LIMIT 50";
      $query = $this->acceso->prepare($sql);
      $query->execute();
      $this->objetos = $query->fetchall();
      return $this->objetos;
    }
  }
  // FIN

  // FUNCION PARA INACTIVAR LOS DATOS DEL LOS CLIENTES REGISTRADOS EN LA BASE DE DATOS
  function inhabilitar($id)
  {
    $sql = "UPDATE cliente SET estatus_cliente = 'INACTIVADO' WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'inactivado';
    } else {
      echo 'noinactivado';
    }
  }
  // FIN

  // FUNCION PARA ACTIVAR LOS DATOS DE LOS CLIENTES REGISTRADOS EN LA BASE DE DATOS
  function habilitar($id)
  {
    $sql = "UPDATE cliente SET estatus_cliente = 'ACTIVO' WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'activo';
    } else {
      echo 'noactivo';
    }
  }
  // FIN

  // FUNCION PARA ELIMINAR LOS DATOS DE LOS CLIENTES REGISTRADOS EN LA BASE DE DATOS
  function eliminar($id)
  {
    $sql = "DELETE FROM cliente WHERE id_cliente=:id";
    $query = $this->acceso->prepare($sql);
    $query->execute(array(':id' => $id));
    if (!empty($query->execute(array(':id' => $id)))) {
      echo 'delete';
    } else {
      echo 'nodelete';
    }
  }
  // FIN

  // FUNCION PARA SELECCIONAR SOLO LOS CLIENTES ACTIVOS 
  function select_cliente()
  {
    $sql = "SELECT * FROM cliente WHERE estatus_cliente = 'ACTIVO' ORDER BY estatus_cliente";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  // FIN

  // FUNCION PARA SELECCIONAR EL CLIENTE
  function select_cliente_usu()
  {
    $sql = "SELECT id_cliente, contacto_usu, usuario.nombre, usuario.apellidos 
        FROM cliente
        INNER JOIN usuario ON cliente.contacto_usu=usuario.id_usuario";
    $query = $this->acceso->prepare($sql);
    $query->execute();
    $this->objetos = $query->fetchall();
    return $this->objetos;
  }
  // FIN

}

// FIN DE LA CLASE
