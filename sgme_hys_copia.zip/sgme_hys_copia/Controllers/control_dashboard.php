<?php
include_once '../Models/dashboard.php';
$dashboard = new  Dashboard();

if ($_POST['funcion']=='datos') {
    $dashboard->datos('usuario');
    $json = array();
    foreach ($dashboard->objetos as $objeto) {
        $json[]=array(
            'usuario'=>$objeto->usuario,
            

        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    
    
}

/*if ($_POST['funcion']=='asignar_equipo') {
    $fecha = $_POST['fecha'];
    $equipo = $_POST['equipo'];
    $cliente = $_POST['cliente'];
    $usuario = $_POST['usuario'];
    $dashboard->usuarios($fecha,$equipo,$cliente,$usuario);
}

if ($_POST['funcion']=='editar_eq_asig') {
    $id_editado = $_POST['id_editado'];
    $fecha = $_POST['fecha'];
    $equipo = $_POST['equipo'];
    $cliente = $_POST['cliente'];
    $usuario = $_POST['usuario'];
    $dashboard->clientes($id_editado,$fecha,$equipo,$cliente,$usuario);
    
}

if ($_POST['funcion']=='buscar_datos') {
    $json = array();
    $dashboard->buscar_eq_asig();
    foreach ($dashboard->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->id_asignar_equipo,
            'fecha'=>$objeto->fecha_hora,
            'equipo'=>$objeto->nombre_equipo,
            'activo'=>$objeto->no_activo,
            'marca'=>$objeto->marca,
            'modelo'=>$objeto->modelo,
            'serial'=>$objeto->serial,
            'propio_tercero'=>$objeto->propio_tercero,
            'fijo_movil'=>$objeto->fijo_movil,
            'pais'=>$objeto->pais,
            'ciudad'=>$objeto->ciudad,
            'sede'=>$objeto->sede,
            'area'=>$objeto->area,
            'cliente'=>$objeto->nombre_cliente,
            'nit'=>$objeto->nit_cliente,
            'tipo_contrato'=>$objeto->tipo_contrato,
            'no_contrato'=>$objeto->num_contrato,
            'usuario'=>$objeto->nombre_usu,
            'apellidos_usu'=>$objeto->apellidos_usu,
            'contacto_usu'=>$objeto->contacto_usu

        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}


if ($_POST['funcion']=='eliminar') {
    $id = $_POST['id'];
    $dashboard->eliminar($id);
}

if ($_POST['funcion']=='total_usuarios') {
    $dashboard->total_usuarios();
    $json = array();
    foreach ($dashboard->objetos as $objeto) {
        $json[]=array(
            'id_tipo'=>$objeto->id_tipo_equipo,
            'nombre'=>$objeto->nombre_tipo_equipo
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}*/
