<?php
include_once '../Models/equipo.php';
$equipo = new  Equipo();

if ($_POST['funcion']=='crear_equipo') {
    $nombre_equipo = $_POST['nombre_equipo'];
    $n_activo = $_POST['n_activo'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $serie = $_POST['serie'];
    $pro_terc = $_POST['pro_terc'];
    $estado = $_POST['estado'];
    $garantia = $_POST['garantia'];
    $equipo->Crear_Equipo($nombre_equipo,$n_activo,$marca,$modelo,$serie,$pro_terc,$estado,$garantia);
}

if ($_POST['funcion']=='editar') {
    $id_editado = $_POST['id_editado'];
    $nombre_equipo = $_POST['nombre'];
    $n_activo = $_POST['n_activo'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $serie = $_POST['serie'];
    $pro_terc = $_POST['pro_terc'];
    $estado = $_POST['estado'];
    $garantia = $_POST['garantia'];
    $equipo->editar($id_editado,$nombre_equipo,$n_activo,$marca,$modelo,$serie,$pro_terc,$estado,$garantia);
    
}

if ($_POST['funcion']=='buscar_datos_equipo') {
    $json=array();
    $equipo->buscador_equipos();
    foreach ($equipo->objetos as $objeto) {
        $json[]=array(
            'id_equipo'=>$objeto->id_equipo,
            'nombre'=>$objeto->nombre,
            'no_activo'=>$objeto->no_activo,
            'marca'=>$objeto->marca,
            'modelo'=>$objeto->modelo,
            'serie'=>$objeto->serie,
            'propio_tercero'=>$objeto->propio_tercero,
            'estado'=>$objeto->estado,
            'garantia'=>$objeto->garantia,
            'estatus'=>$objeto->estatus_eq
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}

if ($_POST['funcion']=='arrendar') {
    $id_equipo = $_POST['id_equipo'];
    $equipo->arrendar($id_equipo);
}

/*if ($_POST['funcion']=='contrato_matto') {
    $id = $_POST['id'];
    $equipo->contrato_matto($id);
}*/

if ($_POST['funcion']=='no_arrendar') {
    $id = $_POST['id'];
    $equipo->no_arrendar($id);
}

if ($_POST['funcion']=='select_equipo') {
    $equipo->select_equipo();
    $json = array();
    foreach ($equipo->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->id_equipo,
            'nombre'=>$objeto->nombre,
            'modelo'=>$objeto->modelo,
            'serie'=>$objeto->serie
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}

if ($_POST['funcion']=='eliminar_eq') {
    $id = $_POST['id'];
    $equipo->eliminar_eq($id);
}

?>