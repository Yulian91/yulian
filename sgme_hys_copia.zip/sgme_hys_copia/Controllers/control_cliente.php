<?php
include_once '../Models/cliente.php';
$cliente = new  Cliente();

if ($_POST['funcion']=='crear_cliente') {
    $nombre = $_POST['nombre'];
    $nit = $_POST['nit'];
    $telefono = $_POST['telefono'];
    $tipo_contrato = $_POST['tipo_contrato'];
    $num_contrato = $_POST['num_contrato'];
    $direccion = $_POST['direccion'];
    $contacto = $_POST['contacto'];
    $email = $_POST['email'];
    $cliente->Crear_Cliente($nombre,$nit,$telefono,$tipo_contrato,$num_contrato,$direccion,$contacto,$email);
}

if ($_POST['funcion']=='editar_cliente') {
    $id_cliente = $_POST['id_cliente'];
    $nombre = $_POST['nombre'];
    $nit = $_POST['nit'];
    $telefono = $_POST['telefono'];
    $tipo_contrato = $_POST['tipo_contrato'];
    $num_contrato = $_POST['num_contrato'];
    $direccion = $_POST['direccion'];
    $contacto = $_POST['contacto'];
    $email = $_POST['email'];
    $cliente->editar_cliente($id_cliente,$nombre,$nit,$telefono,$tipo_contrato,$num_contrato,$direccion,$contacto,$email);
    
}

if ($_POST['funcion']=='buscar_datos_cliente') {
    $json=array();
    $cliente->buscador_clientes();
    foreach ($cliente->objetos as $objeto) {
        $json[]=array(
            'id_cliente'=>$objeto->id_cliente,
            'fecha_registro'=>$objeto->fecha_reg,
            'nombre_cliente'=>$objeto->nombre_rz,
            'nit_cliente'=>$objeto->nit_cliente,
            'telefono_cliente'=>$objeto->telefono_cliente,
            'tipo_contrato'=>$objeto->tipo_contrato,
            'num_contrato'=>$objeto->num_contrato,
            'direccion_cliente'=>$objeto->direccion_ciudad,
            'email_cliente'=>$objeto->email_cliente,
            'nombre_contacto'=>$objeto->nombre_contacto,
            'estatus'=>$objeto->estatus_cliente
            
        );
    }

    // CODIGO PARA CODIFICAR NUESTRO JSON Y CONVERTIRLO EN STRING PARA PODER USAR EL STRING EN GESTION_CLIENTE.JS
    $jsonstring = json_encode($json);
    echo $jsonstring;
    // FIN CODIGO
}

if ($_POST['funcion']=='inhabilitar') {
    $id = $_POST['id'];
    $cliente->inhabilitar($id);
}

if ($_POST['funcion']=='habilitar') {
    $id = $_POST['id'];
    $cliente->habilitar($id);
}

if ($_POST['funcion']=='eliminar') {
    $id = $_POST['id'];
    $cliente->eliminar($id);
}

if ($_POST['funcion']=='select_cliente') {
    $cliente->select_cliente();
    $json = array();
    foreach ($cliente->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->id_cliente,
            'nombre'=>$objeto->nombre_rz
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}

if ($_POST['funcion']=='select_cliente_usu') {
    $cliente->select_cliente_usu();
    $json = array();
    foreach ($cliente->objetos as $objeto) {
        $json[]=array(
            'id'=>$objeto->contacto_usu,
            'nombre'=>$objeto->nombre,
            'apellido'=>$objeto->apellidos
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
}
