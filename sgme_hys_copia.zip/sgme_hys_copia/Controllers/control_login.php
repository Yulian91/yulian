<?php
include_once '../Models/usuario.php';
session_start();
$user = $_POST['user'];
$pass = $_POST['pass'];
$usuario = new Usuario();

// NOS MUESTRA LA SESIÓN EN CURSO

if (!empty($_SESSION['tipo_usu'])) {
  switch ($_SESSION['tipo_usu']) {
    case 1:
      header('Location: ../Views/Admin/Dashboard.php');
      break;

    case 2:
      header('Location: ../Views/Admin/Dashboard.php');
      break;

    case 3:
      header('Location: ../Views/Tecnico/tecn_principal.php');
      break;

    case 4:
      header('Location: ../Views/Cliente/Dashboard.php');
      break;
  }
} else {

  // CODIGO PARA REALIZAR LA CONSULTA A LA BASE DE DATOS E INGRESAR AL SISTEMA
  $usuario->Login($user, $pass);
  if (!empty($usuario->objetos)) {
    foreach ($usuario->objetos as $objeto) {
      $_SESSION['usuario'] = $objeto->id_usuario;
      $_SESSION['tipo_usu'] = $objeto->tipo_usu;
      $_SESSION['nombre'] = $objeto->nombre;
      $_SESSION['apellidos'] = $objeto->apellidos;
    }
    switch ($_SESSION['tipo_usu']) {
      case 1:
        header('Location: ../Views/Admin/Dashboard.php');
        break;

      case 2:
        header('Location: ../Views/Admin/Dashboard.php');
        break;

      case 3:
        header('Location: ../Views/Tecnico/tecn_principal.php');
        break;

      case 4:
        header('Location: ../Views/Cliente/Dashboard.php');
        break;
    }
  } else {
    header('Location: ../index.php');
  }
}
