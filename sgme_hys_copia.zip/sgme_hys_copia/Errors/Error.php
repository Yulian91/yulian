<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Pagina no encontrada</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>

<body>

    <div class="content">
        <a href="Administracion/home" class="pagina">SGME H&S</a>
        <hr>
        <span class="tags">Página no Encontrada</span>
        <p>La página que buscas no existe, ponte en contacto con el administrador.</p>
    </div>

</body>

</html>